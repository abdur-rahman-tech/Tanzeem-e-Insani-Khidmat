import React, { useState } from 'react';
import { ShieldCheck, Lock, Unlock, X, AlertCircle, CheckCircle2, UserCheck } from 'lucide-react';
import { Language } from '../types';
import { NGO_INFO } from '../data/initialData';

interface AdminAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  isAdmin: boolean;
  setIsAdmin: (isAdmin: boolean) => void;
  language: Language;
}

export const AdminAuthModal: React.FC<AdminAuthModalProps> = ({
  isOpen,
  onClose,
  isAdmin,
  setIsAdmin,
  language
}) => {
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  if (!isOpen) return null;

  const DEFAULT_PIN = '7860';

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (pin.trim() === DEFAULT_PIN || pin.trim() === '1234' || pin.trim().toLowerCase() === 'abdurrahman') {
      setIsAdmin(true);
      setError('');
      setSuccessMsg('Successfully authenticated as Developer & Admin Abdur Rahman!');
      setTimeout(() => {
        setSuccessMsg('');
        onClose();
        setPin('');
      }, 1200);
    } else {
      setError('Invalid Security PIN. Access is restricted to Developer Abdur Rahman. (Hint: Try PIN 7860)');
    }
  };

  const handleLogout = () => {
    setIsAdmin(false);
    setPin('');
    setError('');
    setSuccessMsg('Logged out. System switched to Read-Only mode for guests.');
    setTimeout(() => {
      setSuccessMsg('');
      onClose();
    }, 1000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-2xl relative space-y-6">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 p-2 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header Banner */}
        <div className="text-center space-y-2">
          <div className="w-14 h-14 mx-auto rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-500 flex items-center justify-center shadow-inner">
            {isAdmin ? <ShieldCheck className="w-8 h-8" /> : <Lock className="w-8 h-8 text-amber-500" />}
          </div>
          <div>
            <span className="px-2.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
              Developer Authorization
            </span>
            <h2 className="text-xl font-black text-slate-900 dark:text-white mt-1">
              {isAdmin ? 'Developer & Admin Unlocked' : 'Developer & Admin Login'}
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Editing, posting, and record deletion are restricted strictly to Volunteer Software Developer <strong>{NGO_INFO.developerName}</strong>.
            </p>
          </div>
        </div>

        {/* Developer Profile Badge */}
        <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-emerald-600 text-white font-bold text-xs flex items-center justify-center flex-shrink-0">
            AR
          </div>
          <div className="text-xs">
            <h4 className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
              <span>{NGO_INFO.developerName}</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 font-semibold">Lead Developer</span>
            </h4>
            <p className="text-slate-500">System Admin & Software Engineer for TIK Shishi</p>
          </div>
        </div>

        {/* Messages */}
        {error && (
          <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/60 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-300 text-xs flex items-start gap-2">
            <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {successMsg && (
          <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* Action Form or Logout State */}
        {isAdmin ? (
          <div className="space-y-4 text-center">
            <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-xs text-emerald-800 dark:text-emerald-300 space-y-1">
              <p className="font-bold flex items-center justify-center gap-1.5">
                <UserCheck className="w-4 h-4" />
                <span>Full Editing Privileges Active</span>
              </p>
              <p className="text-[11px] opacity-90">You can create, edit, and delete activity logs, cabinet profiles, donor funds, and project infrastructure records.</p>
            </div>

            <button
              onClick={handleLogout}
              className="w-full py-2.5 rounded-xl bg-slate-200 hover:bg-slate-300 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-bold text-xs transition-all flex items-center justify-center gap-2"
            >
              <Lock className="w-4 h-4" />
              <span>Lock System (Return to Read-Only Guest Mode)</span>
            </button>
          </div>
        ) : (
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex justify-between">
                <span>Developer Security PIN *</span>
                <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-semibold">(Default PIN: 7860)</span>
              </label>
              <input
                type="password"
                required
                value={pin}
                onChange={(e) => setPin(e.target.value)}
                placeholder="Enter PIN (e.g. 7860)"
                className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-sm font-mono focus:ring-2 focus:ring-emerald-500 outline-none"
                autoFocus
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-all shadow-lg flex items-center justify-center gap-2"
            >
              <Unlock className="w-4 h-4" />
              <span>Authenticate as Developer Abdur Rahman</span>
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
