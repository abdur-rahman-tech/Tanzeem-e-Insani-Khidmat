import React, { useState } from 'react';
import { 
  HelpCircle, 
  X, 
  CheckCircle2, 
  Send, 
  Droplets, 
  Home, 
  PackageCheck, 
  Sun, 
  AlertCircle 
} from 'lucide-react';
import { AssistanceRequest } from '../types';

interface AssistanceRequestModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmitSuccess: (newReq: AssistanceRequest) => void;
}

export const AssistanceRequestModal: React.FC<AssistanceRequestModalProps> = ({
  isOpen,
  onClose,
  onSubmitSuccess
}) => {
  const [applicantName, setApplicantName] = useState('');
  const [fatherOrHusbandName, setFatherOrHusbandName] = useState('');
  const [village, setVillage] = useState('Tar Village');
  const [contactPhone, setContactPhone] = useState('');
  const [areaOfNeed, setAreaOfNeed] = useState<AssistanceRequest['areaOfNeed']>('house_repair');
  const [familyMembersCount, setFamilyMembersCount] = useState(5);
  const [monthlyIncomePkr, setMonthlyIncomePkr] = useState(0);
  const [description, setDescription] = useState('');
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!applicantName.trim() || !contactPhone.trim()) return;

    const newReq: AssistanceRequest = {
      id: `REQ-2025-${Math.floor(100 + Math.random() * 900)}`,
      applicantName,
      fatherOrHusbandName,
      village,
      contactPhone,
      areaOfNeed,
      description,
      familyMembersCount: Number(familyMembersCount),
      monthlyIncomePkr: Number(monthlyIncomePkr),
      status: 'pending',
      requestDate: new Date().toISOString().split('T')[0]
    };

    onSubmitSuccess(newReq);
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      onClose();
      // Reset
      setApplicantName('');
      setFatherOrHusbandName('');
      setContactPhone('');
      setDescription('');
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-xl w-full p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-6 relative">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 p-2 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
              Community Relief Application
            </span>
            <span className="text-xs text-slate-500 font-urdu">امداد کی درخوست</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white">
            Apply for Assistance / Relief Project
          </h2>
          <p className="text-xs text-slate-500">
            Tanzeem-e-Insani Khidmat (TIK) Shishi field volunteers will verify your case on-site in Shishi, Lower Chitral.
          </p>
        </div>

        {submitted ? (
          <div className="p-8 text-center space-y-3 bg-emerald-50 dark:bg-emerald-950/40 rounded-xl border border-emerald-300 dark:border-emerald-800">
            <CheckCircle2 className="w-12 h-12 text-emerald-600 mx-auto" />
            <h3 className="font-bold text-lg text-emerald-900 dark:text-emerald-200">
              Application Submitted Successfully!
            </h3>
            <p className="text-xs text-emerald-700 dark:text-emerald-300">
              Your request has been logged. TIK Shishi field leads (Abdur Rahman & team) will visit your house for verification.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Applicant Full Name *</label>
                <input
                  type="text"
                  required
                  value={applicantName}
                  onChange={(e) => setApplicantName(e.target.value)}
                  placeholder="e.g. Bibi Samina"
                  className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Father / Husband Name *</label>
                <input
                  type="text"
                  required
                  value={fatherOrHusbandName}
                  onChange={(e) => setFatherOrHusbandName(e.target.value)}
                  placeholder="Late Muhammad Khan"
                  className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Village *</label>
                <select
                  value={village}
                  onChange={(e) => setVillage(e.target.value)}
                  className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                >
                  <option value="Tar Village">Tar Village</option>
                  <option value="Purigal">Purigal</option>
                  <option value="Madaklasht">Madaklasht</option>
                  <option value="Kawash">Kawash</option>
                  <option value="Gorgog">Gorgog</option>
                  <option value="Shishi Village">Shishi Village</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Contact Mobile Phone *</label>
                <input
                  type="text"
                  required
                  value={contactPhone}
                  onChange={(e) => setContactPhone(e.target.value)}
                  placeholder="+92 34X XXXXXXX"
                  className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Area of Need *</label>
                <select
                  value={areaOfNeed}
                  onChange={(e) => setAreaOfNeed(e.target.value as any)}
                  className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs font-semibold"
                >
                  <option value="house_repair">Zero-Cost House Building / Repair</option>
                  <option value="water">Water Pipeline Connection</option>
                  <option value="rashan">Emergency Rashan Pack</option>
                  <option value="solar">Micro-Solar Light Setup</option>
                  <option value="medical_emergency">Emergency Medical Support</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Family Members</label>
                <input
                  type="number"
                  value={familyMembersCount}
                  onChange={(e) => setFamilyMembersCount(Number(e.target.value))}
                  className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Describe Your Need / Situation *</label>
              <textarea
                rows={3}
                required
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Explain family condition, roof status, or missing water connection in detail..."
                className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
              />
            </div>

            <div className="pt-2 flex justify-end gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-lg text-xs font-semibold bg-slate-100 dark:bg-slate-800"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-6 py-2 rounded-lg text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white shadow-md"
              >
                Submit Application
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
