import React, { useState } from 'react';
import { 
  Calendar, 
  MapPin, 
  UserCheck, 
  Users, 
  Heart, 
  Plus, 
  Search, 
  Filter, 
  Camera, 
  FileText,
  X,
  CheckCircle2,
  Droplets,
  Home,
  PackageCheck,
  Sun,
  Boxes,
  Edit3,
  Trash2,
  Lock,
  ShieldCheck,
  KeyRound
} from 'lucide-react';
import { Language, DailyActivity, ActivityCategory } from '../types';
import { INITIAL_DAILY_ACTIVITIES, NGO_INFO } from '../data/initialData';

interface DailyActivityTrackerProps {
  language: Language;
  isAdmin?: boolean;
  onRequestAdminUnlock?: () => void;
}

export const DailyActivityTracker: React.FC<DailyActivityTrackerProps> = ({ 
  language,
  isAdmin = false,
  onRequestAdminUnlock
}) => {
  const [activities, setActivities] = useState<DailyActivity[]>(INITIAL_DAILY_ACTIVITIES);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingActivity, setEditingActivity] = useState<DailyActivity | null>(null);

  // Form State
  const [title, setTitle] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [village, setVillage] = useState('Tar Village');
  const [teamLead, setTeamLead] = useState('Abdur Rahman');
  const [category, setCategory] = useState<ActivityCategory>('water');
  const [description, setDescription] = useState('');
  const [volunteersInvolvedCount, setVolunteersInvolvedCount] = useState(10);
  const [beneficiariesImpactedCount, setBeneficiariesImpactedCount] = useState(100);
  const [photosCount, setPhotosCount] = useState(3);
  const [notes, setNotes] = useState('');

  const filteredActivities = activities.filter(act => {
    const matchesSearch = act.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          act.village.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          act.teamLead.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          act.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCat = selectedCategory === 'all' || act.category === selectedCategory;
    return matchesSearch && matchesCat;
  });

  const handlePostLogClick = () => {
    if (!isAdmin) {
      if (onRequestAdminUnlock) onRequestAdminUnlock();
    } else {
      setIsModalOpen(true);
    }
  };

  const handleEditClick = (act: DailyActivity) => {
    if (!isAdmin) {
      if (onRequestAdminUnlock) onRequestAdminUnlock();
    } else {
      setEditingActivity(act);
    }
  };

  const handleDeleteClick = (id: string) => {
    if (!isAdmin) {
      if (onRequestAdminUnlock) onRequestAdminUnlock();
      return;
    }
    handleDeleteActivity(id);
  };

  const handleCreateActivity = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin) {
      if (onRequestAdminUnlock) onRequestAdminUnlock();
      return;
    }
    if (!title.trim() || !description.trim()) return;

    const newAct: DailyActivity = {
      id: `ACT-2025-${Math.floor(100 + Math.random() * 900)}`,
      date,
      title,
      village,
      teamLead,
      category,
      description,
      volunteersInvolvedCount: Number(volunteersInvolvedCount),
      beneficiariesImpactedCount: Number(beneficiariesImpactedCount),
      photosCount: Number(photosCount),
      notes: notes.trim() || undefined
    };

    setActivities([newAct, ...activities]);
    setIsModalOpen(false);
    // Reset Form
    setTitle('');
    setDescription('');
    setNotes('');
  };

  const handleUpdateActivity = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin) {
      if (onRequestAdminUnlock) onRequestAdminUnlock();
      return;
    }
    if (!editingActivity) return;

    setActivities(activities.map(act => act.id === editingActivity.id ? editingActivity : act));
    setEditingActivity(null);
  };

  const handleDeleteActivity = (id: string) => {
    if (window.confirm(language === 'ur' ? 'کیا آپ اس روزانہ سرگرمی کا ریکارڈ حذف کرنا چاہتے ہیں؟' : 'Are you sure you want to delete this activity log?')) {
      setActivities(activities.filter(act => act.id !== id));
    }
  };

  const getCategoryBadge = (cat: ActivityCategory) => {
    switch (cat) {
      case 'water':
        return <span className="px-2.5 py-0.5 rounded text-xs font-semibold bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300">Water Pipeline</span>;
      case 'house_construction':
        return <span className="px-2.5 py-0.5 rounded text-xs font-semibold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">House Building</span>;
      case 'rashan':
        return <span className="px-2.5 py-0.5 rounded text-xs font-semibold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">Rashan Relief</span>;
      case 'solar':
        return <span className="px-2.5 py-0.5 rounded text-xs font-semibold bg-yellow-100 text-yellow-800 dark:bg-yellow-950 dark:text-yellow-300">Solar Aid</span>;
      case 'karakari':
        return <span className="px-2.5 py-0.5 rounded text-xs font-semibold bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300">Karakari Equipment</span>;
      case 'community_meeting':
        return <span className="px-2.5 py-0.5 rounded text-xs font-semibold bg-teal-100 text-teal-800 dark:bg-teal-950 dark:text-teal-300">Jirga / Meeting</span>;
      default:
        return <span className="px-2.5 py-0.5 rounded text-xs font-semibold bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-300">General Field Log</span>;
    }
  };

  const totalVolunteersEngaged = activities.reduce((acc, a) => acc + a.volunteersInvolvedCount, 0);
  const totalImpacted = activities.reduce((acc, a) => acc + a.beneficiariesImpactedCount, 0);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8">
      {/* Header Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded text-xs font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
              Field Operations Log
            </span>
            <span className="text-xs text-slate-500 font-urdu">روزانہ کارروائی کی رپورٹ</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mt-1">
            Daily Activities & Field Progress Tracker
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1">
            Real-time daily field updates, volunteer deployments, and community progress across Shishi, Lower Chitral.
          </p>
        </div>

        <button
          onClick={handlePostLogClick}
          className={`px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all shadow-lg flex items-center justify-center gap-2 ${
            isAdmin 
              ? 'bg-emerald-600 hover:bg-emerald-500 text-white' 
              : 'bg-amber-600 hover:bg-amber-500 text-white'
          }`}
        >
          {isAdmin ? <Plus className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
          <span>{isAdmin ? 'Post Daily Activity Log' : 'Unlock Developer Mode to Post Log'}</span>
        </button>
      </div>

      {/* Developer Editing Privilege Notice Banner */}
      <div className={`p-4 rounded-2xl border text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
        isAdmin 
          ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800/60 text-emerald-900 dark:text-emerald-200' 
          : 'bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-800/60 text-amber-900 dark:text-amber-200'
      }`}>
        <div className="flex items-center gap-3">
          <div className={`p-2 rounded-xl flex-shrink-0 ${
            isAdmin ? 'bg-emerald-600 text-white' : 'bg-amber-600 text-white'
          }`}>
            {isAdmin ? <ShieldCheck className="w-5 h-5" /> : <Lock className="w-5 h-5" />}
          </div>
          <div>
            <h4 className="font-bold text-sm">
              {isAdmin ? 'Developer & Admin Authorization Active (Abdur Rahman)' : 'Editing Restricted to Volunteer Developer Abdur Rahman'}
            </h4>
            <p className="text-xs opacity-90 mt-0.5">
              {isAdmin 
                ? 'You have full authorization to add, modify, or delete daily activity logs and field records.' 
                : 'All activity posts, edits, and deletions are locked to ensure record integrity. Only Developer Abdur Rahman can modify entries.'}
            </p>
          </div>
        </div>

        {!isAdmin && onRequestAdminUnlock && (
          <button
            onClick={onRequestAdminUnlock}
            className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs transition-all flex items-center gap-1.5 self-start sm:self-auto flex-shrink-0 shadow"
          >
            <KeyRound className="w-3.5 h-3.5" />
            <span>Developer Login / PIN</span>
          </button>
        )}
      </div>

      {/* Summary Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-emerald-50 dark:bg-emerald-950/60 rounded-xl text-emerald-600 dark:text-emerald-400">
            <Calendar className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs text-slate-500 block">Total Activity Logs</span>
            <span className="text-2xl font-black text-slate-900 dark:text-white">{activities.length} Posts</span>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-blue-50 dark:bg-blue-950/60 rounded-xl text-blue-600 dark:text-blue-400">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs text-slate-500 block">Volunteers Deployed</span>
            <span className="text-2xl font-black text-slate-900 dark:text-white">{totalVolunteersEngaged} Person-Days</span>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-purple-50 dark:bg-purple-950/60 rounded-xl text-purple-600 dark:text-purple-400">
            <Heart className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs text-slate-500 block">Beneficiaries Reached</span>
            <span className="text-2xl font-black text-slate-900 dark:text-white">{totalImpacted.toLocaleString()} Residents</span>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row gap-4 justify-between items-center bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
          <input
            type="text"
            placeholder="Search by title, village, lead..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto overflow-x-auto">
          <Filter className="w-4 h-4 text-slate-400 ml-1" />
          {[
            { id: 'all', label: 'All Activities' },
            { id: 'water', label: 'Water' },
            { id: 'house_construction', label: 'Houses' },
            { id: 'karakari', label: 'Karakari' },
            { id: 'rashan', label: 'Rashan' },
            { id: 'solar', label: 'Solar' },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setSelectedCategory(item.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                selectedCategory === item.id
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>

      {/* Activity Timeline / Cards */}
      <div className="space-y-4">
        {filteredActivities.length === 0 ? (
          <div className="text-center py-12 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
            <p className="text-xs text-slate-500">No daily field activities match your search.</p>
          </div>
        ) : (
          filteredActivities.map((act) => (
            <div 
              key={act.id} 
              className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4 hover:border-emerald-500/40 transition-all"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-3">
                  {getCategoryBadge(act.category)}
                  <div className="flex items-center gap-1 text-xs font-semibold text-slate-600 dark:text-slate-400">
                    <Calendar className="w-3.5 h-3.5 text-slate-400" />
                    <span>{act.date}</span>
                  </div>
                </div>

                <div className="flex items-center gap-3 text-xs text-slate-500">
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-emerald-500" />
                    <strong className="text-slate-700 dark:text-slate-300">{act.village}</strong>
                  </span>
                  <span>•</span>
                  <span className="flex items-center gap-1">
                    <UserCheck className="w-3.5 h-3.5 text-blue-500" />
                    <span>Lead: <strong>{act.teamLead}</strong></span>
                  </span>
                  <div className="flex items-center gap-1 ml-2 pl-2 border-l border-slate-200 dark:border-slate-800">
                    <button
                      onClick={() => handleEditClick(act)}
                      className={`p-1 rounded transition-colors ${
                        isAdmin 
                          ? 'text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950' 
                          : 'text-amber-500 hover:text-amber-600 hover:bg-amber-50 dark:hover:bg-amber-950'
                      }`}
                      title={isAdmin ? "Edit Activity Log" : "Unlock Developer Mode to Edit"}
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteClick(act.id)}
                      className={`p-1 rounded transition-colors ${
                        isAdmin 
                          ? 'text-slate-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950' 
                          : 'text-slate-300 hover:text-amber-600'
                      }`}
                      title={isAdmin ? "Delete Activity Log" : "Unlock Developer Mode to Delete"}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <h3 className="font-bold text-base text-slate-900 dark:text-white">
                  {act.title}
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  {act.description}
                </p>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-4 pt-3 border-t border-slate-100 dark:border-slate-800 text-xs text-slate-500">
                <div className="flex items-center gap-4">
                  <span className="flex items-center gap-1.5 font-medium text-slate-700 dark:text-slate-300">
                    <Users className="w-3.5 h-3.5 text-emerald-500" />
                    <span>{act.volunteersInvolvedCount} Volunteers Engaged</span>
                  </span>

                  <span className="flex items-center gap-1.5 font-medium text-slate-700 dark:text-slate-300">
                    <Heart className="w-3.5 h-3.5 text-red-500" />
                    <span>{act.beneficiariesImpactedCount} Beneficiaries Impacted</span>
                  </span>

                  <span className="flex items-center gap-1.5 text-slate-500">
                    <Camera className="w-3.5 h-3.5 text-purple-500" />
                    <span>{act.photosCount} Field Photos Archived</span>
                  </span>
                </div>

                {act.notes && (
                  <p className="text-[11px] text-slate-500 bg-slate-50 dark:bg-slate-950 px-3 py-1 rounded-lg border border-slate-200 dark:border-slate-800 italic">
                    Note: {act.notes}
                  </p>
                )}
              </div>
            </div>
          ))
        )}
      </div>

      {/* Modal to Upload/Post New Activity Log */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-xl w-full p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-6 relative">
            <button
              onClick={() => setIsModalOpen(false)}
              className="absolute right-4 top-4 p-2 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="space-y-1">
              <span className="px-2.5 py-0.5 rounded text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
                Daily Field Activity Upload
              </span>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">
                Record Daily Field Activity
              </h2>
              <p className="text-xs text-slate-500">
                Log completed work, volunteer turnout, and location updates for TIK Shishi records.
              </p>
            </div>

            <form onSubmit={handleCreateActivity} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1 sm:col-span-2">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Activity Title *</label>
                  <input
                    type="text"
                    required
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g. Tar Village Pipeline Pipe Jointing & Excavation"
                    className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Activity Date *</label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Category *</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as any)}
                    className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs font-semibold"
                  >
                    <option value="water">Water Supply Infrastructure</option>
                    <option value="house_construction">House Building / Repair</option>
                    <option value="karakari">Karakari Equipment Logistics</option>
                    <option value="rashan">Rashan Distribution</option>
                    <option value="solar">Solar Aid & Lighting</option>
                    <option value="community_meeting">Village Council / Jirga</option>
                    <option value="general">General Field Operations</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Village Location *</label>
                  <select
                    value={village}
                    onChange={(e) => setVillage(e.target.value)}
                    className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                  >
                    <option value="Tar Village">Tar Village</option>
                    <option value="Purigal">Purigal</option>
                    <option value="Madaklasht">Madaklasht</option>
                    <option value="Kawash">Kawash</option>
                    <option value="Gorgog">Gorgog</option>
                    <option value="Shishi Village">Shishi Village</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Team Lead / Author *</label>
                  <input
                    type="text"
                    required
                    value={teamLead}
                    onChange={(e) => setTeamLead(e.target.value)}
                    placeholder="e.g. Abdur Rahman"
                    className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Volunteers Engaged</label>
                  <input
                    type="number"
                    value={volunteersInvolvedCount}
                    onChange={(e) => setVolunteersInvolvedCount(Number(e.target.value))}
                    className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Beneficiaries Reached</label>
                  <input
                    type="number"
                    value={beneficiariesImpactedCount}
                    onChange={(e) => setBeneficiariesImpactedCount(Number(e.target.value))}
                    className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Activity Details / Work Done *</label>
                <textarea
                  rows={3}
                  required
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Describe tasks completed, materials used, or challenges encountered..."
                  className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Technical Notes / Observations</label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="e.g. Pipe pressure tested. Next phase scheduled for tomorrow."
                  className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                />
              </div>

              <div className="pt-2 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-lg text-xs font-semibold bg-slate-100 dark:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 rounded-lg text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white shadow-md"
                >
                  Post Activity Log
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Activity Modal */}
      {editingActivity && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-xl w-full p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-6 relative">
            <button
              onClick={() => setEditingActivity(null)}
              className="absolute right-4 top-4 p-2 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="space-y-1">
              <span className="px-2.5 py-0.5 rounded text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
                Edit Activity Log
              </span>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">
                Update {editingActivity.title}
              </h2>
            </div>

            <form onSubmit={handleUpdateActivity} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1 sm:col-span-2">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Activity Title *</label>
                  <input
                    type="text"
                    required
                    value={editingActivity.title}
                    onChange={(e) => setEditingActivity({ ...editingActivity, title: e.target.value })}
                    className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs font-bold"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Date *</label>
                  <input
                    type="date"
                    required
                    value={editingActivity.date}
                    onChange={(e) => setEditingActivity({ ...editingActivity, date: e.target.value })}
                    className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Village *</label>
                  <select
                    value={editingActivity.village}
                    onChange={(e) => setEditingActivity({ ...editingActivity, village: e.target.value })}
                    className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                  >
                    <option value="Tar Village">Tar Village</option>
                    <option value="Purigal">Purigal</option>
                    <option value="Madaklasht">Madaklasht</option>
                    <option value="Kawash">Kawash</option>
                    <option value="Gorgog">Gorgog</option>
                    <option value="Shishi Village">Shishi Village</option>
                    <option value="Uzurbek">Uzurbek</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Team Lead *</label>
                  <input
                    type="text"
                    required
                    value={editingActivity.teamLead}
                    onChange={(e) => setEditingActivity({ ...editingActivity, teamLead: e.target.value })}
                    className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Category *</label>
                  <select
                    value={editingActivity.category}
                    onChange={(e) => setEditingActivity({ ...editingActivity, category: e.target.value as ActivityCategory })}
                    className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs font-semibold"
                  >
                    <option value="water">Water Pipeline</option>
                    <option value="house_construction">House Building</option>
                    <option value="rashan">Rashan Relief</option>
                    <option value="solar">Solar Aid</option>
                    <option value="karakari">Karakari Equipment</option>
                    <option value="community_meeting">Jirga / Meeting</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Volunteers Engaged</label>
                  <input
                    type="number"
                    value={editingActivity.volunteersInvolvedCount}
                    onChange={(e) => setEditingActivity({ ...editingActivity, volunteersInvolvedCount: Number(e.target.value) })}
                    className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Beneficiaries Reached</label>
                  <input
                    type="number"
                    value={editingActivity.beneficiariesImpactedCount}
                    onChange={(e) => setEditingActivity({ ...editingActivity, beneficiariesImpactedCount: Number(e.target.value) })}
                    className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Activity Details / Work Done *</label>
                <textarea
                  rows={3}
                  required
                  value={editingActivity.description}
                  onChange={(e) => setEditingActivity({ ...editingActivity, description: e.target.value })}
                  className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Technical Notes</label>
                <input
                  type="text"
                  value={editingActivity.notes || ''}
                  onChange={(e) => setEditingActivity({ ...editingActivity, notes: e.target.value })}
                  className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                />
              </div>

              <div className="pt-2 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setEditingActivity(null)}
                  className="px-4 py-2 rounded-lg text-xs font-semibold bg-slate-100 dark:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 rounded-lg text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white shadow-md"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
