import React, { useState } from 'react';
import { 
  Coins, 
  Users, 
  Plus, 
  Search, 
  Receipt, 
  CreditCard, 
  Calendar, 
  Building2, 
  FileSpreadsheet, 
  X, 
  CheckCircle2, 
  ArrowUpRight, 
  Phone, 
  Mail, 
  Globe2, 
  Filter,
  ShieldCheck,
  TrendingUp,
  UserCheck,
  Edit3,
  Trash2
} from 'lucide-react';
import { Language, DonorAccount, DonationRecord, DesignatedCause } from '../types';
import { INITIAL_DONOR_ACCOUNTS, INITIAL_DONATIONS } from '../data/initialData';

interface FundsAndDonorsTrackerProps {
  language: Language;
  isAdmin?: boolean;
  onRequestAdminUnlock?: () => void;
}

export const FundsAndDonorsTracker: React.FC<FundsAndDonorsTrackerProps> = ({ 
  language,
  isAdmin = false,
  onRequestAdminUnlock
}) => {
  const [donorAccounts, setDonorAccounts] = useState<DonorAccount[]>(INITIAL_DONOR_ACCOUNTS);
  const [donations, setDonations] = useState<DonationRecord[]>(INITIAL_DONATIONS);

  const [activeTab, setActiveTab] = useState<'donations_list' | 'donors_accounts'>('donations_list');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCauseFilter, setSelectedCauseFilter] = useState<string>('all');
  const [selectedDonorDetail, setSelectedDonorDetail] = useState<DonorAccount | null>(null);

  // Modals state
  const [isNewDonationModalOpen, setIsNewDonationModalOpen] = useState(false);
  const [isNewDonorModalOpen, setIsNewDonorModalOpen] = useState(false);

  // Editing state
  const [editingDonation, setEditingDonation] = useState<DonationRecord | null>(null);
  const [editingDonor, setEditingDonor] = useState<DonorAccount | null>(null);

  // New Donation Form State
  const [donorId, setDonorId] = useState('DNR-001');
  const [amountPkr, setAmountPkr] = useState<number>(50000);
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [paymentMethod, setPaymentMethod] = useState<DonationRecord['paymentMethod']>('Bank Transfer');
  const [allocatedCause, setAllocatedCause] = useState<DesignatedCause>('Water Supply Infrastructure');
  const [notes, setNotes] = useState('');

  // New Donor Account Form State
  const [newDonorName, setNewDonorName] = useState('');
  const [cityOrCountry, setCityOrCountry] = useState('Islamabad, Pakistan');
  const [contactPhone, setContactPhone] = useState('');
  const [email, setEmail] = useState('');
  const [initialNotes, setInitialNotes] = useState('');

  // Calculations
  const totalFundsRaisedPkr = donations.reduce((sum, d) => sum + d.amountPkr, 0);
  const totalGiversCount = donorAccounts.length;

  const causeTotals = donations.reduce((acc, d) => {
    acc[d.allocatedCause] = (acc[d.allocatedCause] || 0) + d.amountPkr;
    return acc;
  }, {} as Record<string, number>);

  // Handle Recording New Donation
  const handleRecordDonation = (e: React.FormEvent) => {
    e.preventDefault();
    if (amountPkr <= 0) return;

    const matchedDonor = donorAccounts.find(d => d.id === donorId);
    if (!matchedDonor) return;

    const receiptNo = `REC-TIK-2025-${Math.floor(100 + Math.random() * 900)}`;

    const newDonation: DonationRecord = {
      id: `DON-2025-${Math.floor(100 + Math.random() * 900)}`,
      donorId: matchedDonor.id,
      donorName: matchedDonor.fullName,
      amountPkr: Number(amountPkr),
      date,
      paymentMethod,
      receiptNo,
      allocatedCause,
      notes: notes.trim() || undefined
    };

    setDonations([newDonation, ...donations]);

    // Update Donor Account totals
    setDonorAccounts(donorAccounts.map(account => {
      if (account.id === matchedDonor.id) {
        return {
          ...account,
          totalContributedPkr: account.totalContributedPkr + Number(amountPkr),
          totalTransactionsCount: account.totalTransactionsCount + 1,
          lastDonationDate: date
        };
      }
      return account;
    }));

    setIsNewDonationModalOpen(false);
    setAmountPkr(50000);
    setNotes('');
  };

  // Handle Creating New Donor Account
  const handleCreateDonorAccount = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDonorName.trim()) return;

    const newAccount: DonorAccount = {
      id: `DNR-${Math.floor(100 + Math.random() * 900)}`,
      fullName: newDonorName,
      cityOrCountry,
      contactPhone: contactPhone.trim() || undefined,
      email: email.trim() || undefined,
      totalContributedPkr: 0,
      totalTransactionsCount: 0,
      firstDonationDate: new Date().toISOString().split('T')[0],
      lastDonationDate: new Date().toISOString().split('T')[0],
      notes: initialNotes.trim() || undefined
    };

    setDonorAccounts([...donorAccounts, newAccount]);
    setIsNewDonorModalOpen(false);
    setNewDonorName('');
    setContactPhone('');
    setEmail('');
    setInitialNotes('');
  };

  const handleUpdateDonation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingDonation) return;

    setDonations(donations.map(d => d.id === editingDonation.id ? editingDonation : d));
    setEditingDonation(null);
  };

  const handleDeleteDonation = (id: string) => {
    if (window.confirm(language === 'ur' ? 'کیا آپ اس عطیہ کا ریکارڈ حذف کرنا چاہتے ہیں؟' : 'Are you sure you want to delete this donation record?')) {
      setDonations(donations.filter(d => d.id !== id));
    }
  };

  const handleUpdateDonor = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingDonor) return;

    setDonorAccounts(donorAccounts.map(acc => acc.id === editingDonor.id ? editingDonor : acc));
    setEditingDonor(null);
  };

  const handleDeleteDonor = (id: string) => {
    if (window.confirm(language === 'ur' ? 'کیا آپ اس ڈونر اکاؤنٹ کو حذف کرنا چاہتے ہیں؟' : 'Are you sure you want to delete this donor account?')) {
      setDonorAccounts(donorAccounts.filter(acc => acc.id !== id));
      if (selectedDonorDetail?.id === id) {
        setSelectedDonorDetail(null);
      }
    }
  };

  const filteredDonations = donations.filter(don => {
    const matchesSearch = don.donorName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          don.receiptNo.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          don.allocatedCause.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCause = selectedCauseFilter === 'all' || don.allocatedCause === selectedCauseFilter;
    return matchesSearch && matchesCause;
  });

  const filteredDonors = donorAccounts.filter(acc => {
    return acc.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
           acc.cityOrCountry.toLowerCase().includes(searchQuery.toLowerCase());
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8">
      {/* Header Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded text-xs font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
              Donor Ledger & Account Management
            </span>
            <span className="text-xs text-slate-500 font-urdu">مالی عطیات اور فنڈز کا ریکارڈ</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mt-1">
            Fundraising, Donor Accounts & Financial Receipts
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1">
            Track money contributions, donor accounts, and verified project allocation receipts for TIK Shishi.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => setIsNewDonorModalOpen(true)}
            className="px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold bg-slate-800 hover:bg-slate-700 text-white transition-all shadow-md flex items-center gap-2"
          >
            <UserCheck className="w-4 h-4 text-emerald-400" />
            <span>Register Donor Account</span>
          </button>

          <button
            onClick={() => setIsNewDonationModalOpen(true)}
            className="px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold bg-emerald-600 hover:bg-emerald-500 text-white transition-all shadow-lg flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            <span>Record New Donation</span>
          </button>
        </div>
      </div>

      {/* Top Financial Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500">Total Funds Raised</span>
            <div className="p-2 bg-emerald-50 dark:bg-emerald-950/60 rounded-lg text-emerald-600 dark:text-emerald-400">
              <Coins className="w-5 h-5" />
            </div>
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white">
            PKR {totalFundsRaisedPkr.toLocaleString()}
          </div>
          <p className="text-[11px] text-emerald-600 dark:text-emerald-400 font-medium flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>0% Administrative Deduction</span>
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500">Registered Donors / Givers</span>
            <div className="p-2 bg-blue-50 dark:bg-blue-950/60 rounded-lg text-blue-600 dark:text-blue-400">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white">
            {totalGiversCount} Accounts
          </div>
          <p className="text-[11px] text-slate-500">
            Local & Overseas Diaspora Contributors
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500">Water Lines Allocation</span>
            <div className="p-2 bg-teal-50 dark:bg-teal-950/60 rounded-lg text-teal-600 dark:text-teal-400">
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white">
            PKR {(causeTotals['Water Supply Infrastructure'] || 0).toLocaleString()}
          </div>
          <p className="text-[11px] text-slate-500">
            HDPE pipes & stream filter chambers
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500">House Building & Karakari</span>
            <div className="p-2 bg-purple-50 dark:bg-purple-950/60 rounded-lg text-purple-600 dark:text-purple-400">
              <Receipt className="w-5 h-5" />
            </div>
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white">
            PKR {((causeTotals['Zero-Cost House Construction'] || 0) + (causeTotals['Karakari Equipment Cabinet'] || 0)).toLocaleString()}
          </div>
          <p className="text-[11px] text-slate-500">
            Zero-cost widow homes & cooking equipment
          </p>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4 bg-white dark:bg-slate-900 p-3 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <button
            onClick={() => setActiveTab('donations_list')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'donations_list'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
            }`}
          >
            <Receipt className="w-4 h-4" />
            <span>Donation Transactions ({donations.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('donors_accounts')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'donors_accounts'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Givers / Donor Accounts ({donorAccounts.length})</span>
          </button>
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            placeholder={activeTab === 'donations_list' ? "Search donor or receipt..." : "Search giver name or city..."}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white"
          />
        </div>
      </div>

      {/* View 1: Donation Transactions List */}
      {activeTab === 'donations_list' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
          <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center">
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">
              Financial Receipts & Donation Ledger
            </h3>
            <span className="text-xs text-slate-500">
              Showing {filteredDonations.length} records
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-700 dark:text-slate-300">
              <thead className="bg-slate-50 dark:bg-slate-950 text-slate-500 font-bold uppercase tracking-wider text-[10px] border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="p-3.5">Receipt #</th>
                  <th className="p-3.5">Giver / Donor Name</th>
                  <th className="p-3.5">Amount (PKR)</th>
                  <th className="p-3.5">Designated Cause</th>
                  <th className="p-3.5">Payment Method</th>
                  <th className="p-3.5">Date</th>
                  <th className="p-3.5">Notes</th>
                  <th className="p-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800 font-medium">
                {filteredDonations.map((don) => (
                  <tr key={don.id} className="hover:bg-slate-50 dark:hover:bg-slate-950/50 transition-colors">
                    <td className="p-3.5 font-mono text-emerald-600 dark:text-emerald-400 font-bold">
                      {don.receiptNo}
                    </td>
                    <td className="p-3.5 font-bold text-slate-900 dark:text-white">
                      {don.donorName}
                    </td>
                    <td className="p-3.5 font-bold text-emerald-600 dark:text-emerald-400 text-sm">
                      PKR {don.amountPkr.toLocaleString()}
                    </td>
                    <td className="p-3.5">
                      <span className="px-2.5 py-1 rounded-full text-[11px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200">
                        {don.allocatedCause}
                      </span>
                    </td>
                    <td className="p-3.5">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-300">
                        {don.paymentMethod}
                      </span>
                    </td>
                    <td className="p-3.5 text-slate-500">
                      {don.date}
                    </td>
                    <td className="p-3.5 text-slate-500 max-w-xs truncate">
                      {don.notes || '—'}
                    </td>
                    <td className="p-3.5 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => setEditingDonation(don)}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950 transition-colors"
                          title="Edit Donation"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteDonation(don.id)}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950 transition-colors"
                          title="Delete Donation"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* View 2: Donor Accounts Directory */}
      {activeTab === 'donors_accounts' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredDonors.map((account) => (
            <div 
              key={account.id}
              className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4 hover:border-emerald-500/40 transition-all flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex justify-between items-start">
                  <div>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                      ID: {account.id}
                    </span>
                    <h3 className="font-bold text-lg text-slate-900 dark:text-white mt-1">
                      {account.fullName}
                    </h3>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => setEditingDonor(account)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950 transition-colors"
                      title="Edit Donor"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteDonor(account.id)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950 transition-colors"
                      title="Delete Donor"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                    <div className="p-2 bg-emerald-50 dark:bg-emerald-950/60 rounded-xl text-emerald-600 dark:text-emerald-400">
                      <UserCheck className="w-4 h-4" />
                    </div>
                  </div>
                </div>

                <div className="space-y-1 text-xs text-slate-500">
                  <p className="flex items-center gap-1.5 text-slate-700 dark:text-slate-300 font-medium">
                    <Globe2 className="w-3.5 h-3.5 text-slate-400" />
                    <span>{account.cityOrCountry}</span>
                  </p>

                  {account.contactPhone && (
                    <p className="flex items-center gap-1.5">
                      <Phone className="w-3.5 h-3.5 text-slate-400" />
                      <span>{account.contactPhone}</span>
                    </p>
                  )}
                </div>

                <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800 space-y-1">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Total Contributions</span>
                  <div className="text-xl font-black text-emerald-600 dark:text-emerald-400">
                    PKR {account.totalContributedPkr.toLocaleString()}
                  </div>
                  <div className="flex justify-between text-[11px] text-slate-500 pt-1">
                    <span>{account.totalTransactionsCount} Donations</span>
                    <span>Last: {account.lastDonationDate}</span>
                  </div>
                </div>

                {account.notes && (
                  <p className="text-xs text-slate-500 italic">
                    "{account.notes}"
                  </p>
                )}
              </div>

              <button
                onClick={() => setSelectedDonorDetail(account)}
                className="w-full mt-4 py-2 text-xs font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/50 hover:bg-emerald-100 rounded-xl transition-all flex items-center justify-center gap-1"
              >
                <span>View Contribution History</span>
                <ArrowUpRight className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Modal: Donor Contribution History Detail */}
      {selectedDonorDetail && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-2xl w-full p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-6 relative">
            <button
              onClick={() => setSelectedDonorDetail(null)}
              className="absolute right-4 top-4 p-2 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="space-y-2 border-b border-slate-200 dark:border-slate-800 pb-4">
              <span className="px-2.5 py-0.5 rounded text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
                Giver / Donor Account History
              </span>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">
                {selectedDonorDetail.fullName}
              </h2>
              <p className="text-xs text-slate-500">
                Location: {selectedDonorDetail.cityOrCountry} | Total Contributed: <strong className="text-emerald-600">PKR {selectedDonorDetail.totalContributedPkr.toLocaleString()}</strong>
              </p>
            </div>

            <div className="space-y-3 max-h-80 overflow-y-auto">
              <h3 className="font-bold text-xs uppercase tracking-wider text-slate-500">
                Transaction Ledger ({selectedDonorDetail.totalTransactionsCount} Items)
              </h3>

              {donations.filter(d => d.donorId === selectedDonorDetail.id).map(don => (
                <div key={don.id} className="p-3.5 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800 flex justify-between items-center text-xs">
                  <div>
                    <span className="font-mono text-emerald-600 font-bold">{don.receiptNo}</span>
                    <p className="font-bold text-slate-900 dark:text-white">{don.allocatedCause}</p>
                    <p className="text-[11px] text-slate-500">{don.date} • {don.paymentMethod}</p>
                  </div>

                  <div className="text-right font-black text-sm text-emerald-600 dark:text-emerald-400">
                    PKR {don.amountPkr.toLocaleString()}
                  </div>
                </div>
              ))}
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setSelectedDonorDetail(null)}
                className="px-5 py-2 rounded-lg text-xs font-bold bg-slate-800 text-white"
              >
                Close Record
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Record New Donation */}
      {isNewDonationModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-lg w-full p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-6 relative">
            <button
              onClick={() => setIsNewDonationModalOpen(false)}
              className="absolute right-4 top-4 p-2 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="space-y-1">
              <span className="px-2.5 py-0.5 rounded text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
                Record Financial Donation
              </span>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">
                Log New Donation & Issue Receipt
              </h2>
            </div>

            <form onSubmit={handleRecordDonation} className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Select Giver / Donor Account *</label>
                <select
                  value={donorId}
                  onChange={(e) => setDonorId(e.target.value)}
                  className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs font-semibold"
                >
                  {donorAccounts.map((account) => (
                    <option key={account.id} value={account.id}>
                      {account.fullName} ({account.cityOrCountry})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Amount (PKR) *</label>
                  <input
                    type="number"
                    required
                    min={100}
                    value={amountPkr}
                    onChange={(e) => setAmountPkr(Number(e.target.value))}
                    className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs font-bold"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Donation Date *</label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Designated Cause *</label>
                  <select
                    value={allocatedCause}
                    onChange={(e) => setAllocatedCause(e.target.value as any)}
                    className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                  >
                    <option value="Water Supply Infrastructure">Water Supply Infrastructure</option>
                    <option value="Zero-Cost House Construction">Zero-Cost House Construction</option>
                    <option value="Karakari Equipment Cabinet">Karakari Equipment Cabinet</option>
                    <option value="Smart Rashan Packs">Smart Rashan Food Packs</option>
                    <option value="Solar Aid">Solar Aid & Lighting</option>
                    <option value="General Welfare">General Welfare</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Payment Channel *</label>
                  <select
                    value={paymentMethod}
                    onChange={(e) => setPaymentMethod(e.target.value as any)}
                    className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                  >
                    <option value="Bank Transfer">Bank Transfer</option>
                    <option value="EasyPaisa">EasyPaisa</option>
                    <option value="JazzCash">JazzCash</option>
                    <option value="Cash">Direct Cash</option>
                    <option value="Overseas Wire">Overseas Wire</option>
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Notes / Reference</label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="e.g. Bank reference #, specific project instruction..."
                  className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                />
              </div>

              <div className="pt-2 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsNewDonationModalOpen(false)}
                  className="px-4 py-2 rounded-lg text-xs font-semibold bg-slate-100 dark:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 rounded-lg text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white shadow-md"
                >
                  Save & Issue Receipt
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Create New Donor Account */}
      {isNewDonorModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-lg w-full p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-6 relative">
            <button
              onClick={() => setIsNewDonorModalOpen(false)}
              className="absolute right-4 top-4 p-2 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="space-y-1">
              <span className="px-2.5 py-0.5 rounded text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
                New Giver / Donor Account
              </span>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">
                Register Donor Account Profile
              </h2>
            </div>

            <form onSubmit={handleCreateDonorAccount} className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Giver / Donor Full Name *</label>
                <input
                  type="text"
                  required
                  value={newDonorName}
                  onChange={(e) => setNewDonorName(e.target.value)}
                  placeholder="e.g. Haji Muhammad Ali"
                  className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">City / Country *</label>
                <input
                  type="text"
                  required
                  value={cityOrCountry}
                  onChange={(e) => setCityOrCountry(e.target.value)}
                  placeholder="e.g. Peshawar, Pakistan or London, UK"
                  className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Contact Phone</label>
                  <input
                    type="text"
                    value={contactPhone}
                    onChange={(e) => setContactPhone(e.target.value)}
                    placeholder="+92 3XX XXXXXXX"
                    className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Email Address</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="donor@example.com"
                    className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Notes / Affiliation</label>
                <input
                  type="text"
                  value={initialNotes}
                  onChange={(e) => setInitialNotes(e.target.value)}
                  placeholder="e.g. Member of Chitral Welfare Society"
                  className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                />
              </div>

              <div className="pt-2 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsNewDonorModalOpen(false)}
                  className="px-4 py-2 rounded-lg text-xs font-semibold bg-slate-100 dark:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 rounded-lg text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white shadow-md"
                >
                  Create Account
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Edit Donation */}
      {editingDonation && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-lg w-full p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-6 relative">
            <button
              onClick={() => setEditingDonation(null)}
              className="absolute right-4 top-4 p-2 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="space-y-1">
              <span className="px-2.5 py-0.5 rounded text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
                Edit Donation Record
              </span>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">
                Receipt #{editingDonation.receiptNo}
              </h2>
            </div>

            <form onSubmit={handleUpdateDonation} className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Donor Name *</label>
                <input
                  type="text"
                  required
                  value={editingDonation.donorName}
                  onChange={(e) => setEditingDonation({ ...editingDonation, donorName: e.target.value })}
                  className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs font-bold"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Amount (PKR) *</label>
                  <input
                    type="number"
                    required
                    value={editingDonation.amountPkr}
                    onChange={(e) => setEditingDonation({ ...editingDonation, amountPkr: Number(e.target.value) })}
                    className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs font-bold text-emerald-600"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Date *</label>
                  <input
                    type="date"
                    required
                    value={editingDonation.date}
                    onChange={(e) => setEditingDonation({ ...editingDonation, date: e.target.value })}
                    className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Designated Cause *</label>
                <select
                  value={editingDonation.allocatedCause}
                  onChange={(e) => setEditingDonation({ ...editingDonation, allocatedCause: e.target.value as DesignatedCause })}
                  className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs font-semibold"
                >
                  <option value="Water Supply Infrastructure">Water Supply Infrastructure</option>
                  <option value="Zero-Cost Widow Housing">Zero-Cost Widow Housing</option>
                  <option value="Smart Rashan Distribution">Smart Rashan Distribution</option>
                  <option value="Solar Community Power">Solar Community Power</option>
                  <option value="Karakari Equipment Pool">Karakari Equipment Pool</option>
                  <option value="General Operations & Emergency Relief">General Operations & Emergency Relief</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Notes / Remarks</label>
                <input
                  type="text"
                  value={editingDonation.notes || ''}
                  onChange={(e) => setEditingDonation({ ...editingDonation, notes: e.target.value })}
                  className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                />
              </div>

              <div className="pt-2 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setEditingDonation(null)}
                  className="px-4 py-2 rounded-lg text-xs font-semibold bg-slate-100 dark:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 rounded-lg text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white shadow-md"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Edit Donor Account */}
      {editingDonor && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-lg w-full p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-6 relative">
            <button
              onClick={() => setEditingDonor(null)}
              className="absolute right-4 top-4 p-2 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="space-y-1">
              <span className="px-2.5 py-0.5 rounded text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
                Edit Donor Account
              </span>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">
                Update Account #{editingDonor.id}
              </h2>
            </div>

            <form onSubmit={handleUpdateDonor} className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Full Name *</label>
                <input
                  type="text"
                  required
                  value={editingDonor.fullName}
                  onChange={(e) => setEditingDonor({ ...editingDonor, fullName: e.target.value })}
                  className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs font-bold"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Location (City / Country) *</label>
                <input
                  type="text"
                  required
                  value={editingDonor.cityOrCountry}
                  onChange={(e) => setEditingDonor({ ...editingDonor, cityOrCountry: e.target.value })}
                  className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Contact Phone</label>
                  <input
                    type="text"
                    value={editingDonor.contactPhone || ''}
                    onChange={(e) => setEditingDonor({ ...editingDonor, contactPhone: e.target.value })}
                    className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Email Address</label>
                  <input
                    type="email"
                    value={editingDonor.email || ''}
                    onChange={(e) => setEditingDonor({ ...editingDonor, email: e.target.value })}
                    className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Total Contributed (PKR)</label>
                <input
                  type="number"
                  value={editingDonor.totalContributedPkr}
                  onChange={(e) => setEditingDonor({ ...editingDonor, totalContributedPkr: Number(e.target.value) })}
                  className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs font-bold text-emerald-600"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Notes / Remarks</label>
                <input
                  type="text"
                  value={editingDonor.notes || ''}
                  onChange={(e) => setEditingDonor({ ...editingDonor, notes: e.target.value })}
                  className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                />
              </div>

              <div className="pt-2 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setEditingDonor(null)}
                  className="px-4 py-2 rounded-lg text-xs font-semibold bg-slate-100 dark:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 rounded-lg text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white shadow-md"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
