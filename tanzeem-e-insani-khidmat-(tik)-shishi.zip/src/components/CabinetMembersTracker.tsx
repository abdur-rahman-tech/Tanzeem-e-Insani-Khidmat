import React, { useState } from 'react';
import { 
  Users, 
  ShieldCheck, 
  Phone, 
  Mail, 
  MapPin, 
  UserPlus, 
  Search, 
  Code2, 
  Briefcase,
  CheckCircle2,
  X,
  Building,
  Award,
  Edit3,
  Trash2,
  Image,
  Save,
  Upload,
  Camera
} from 'lucide-react';
import { Language, CabinetMember } from '../types';
import { NGO_INFO, INITIAL_CABINET_MEMBERS } from '../data/initialData';
import { Lock, KeyRound } from 'lucide-react';

interface CabinetMembersTrackerProps {
  language: Language;
  isAdmin?: boolean;
  onRequestAdminUnlock?: () => void;
}

const PRESET_PHOTOS = [
  { label: 'Executive Male 1', url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=500&auto=format&fit=crop&q=80' },
  { label: 'Executive Male 2', url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=500&auto=format&fit=crop&q=80' },
  { label: 'Senior Officer', url: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=500&auto=format&fit=crop&q=80' },
  { label: 'Field Lead', url: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=500&auto=format&fit=crop&q=80' },
  { label: 'Operations Director', url: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=500&auto=format&fit=crop&q=80' },
  { label: 'Tech Lead / Volunteer', url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=500&auto=format&fit=crop&q=80' }
];

export const CabinetMembersTracker: React.FC<CabinetMembersTrackerProps> = ({ 
  language,
  isAdmin = false,
  onRequestAdminUnlock
}) => {
  const [members, setMembers] = useState<CabinetMember[]>(INITIAL_CABINET_MEMBERS);
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedMember, setSelectedMember] = useState<CabinetMember | null>(null);
  const [editingMember, setEditingMember] = useState<CabinetMember | null>(null);

  // New member form state
  const [newMember, setNewMember] = useState<Partial<CabinetMember>>({
    name: '',
    role: '',
    roleUrdu: '',
    location: 'Shishi London, Drosh, Lower Chitral',
    phone: '',
    email: '',
    bio: '',
    photoUrl: PRESET_PHOTOS[0].url,
    isDeveloperVolunteer: false
  });

  const filteredMembers = members.filter(member => 
    member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    member.role.toLowerCase().includes(searchTerm.toLowerCase()) ||
    member.location.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleAddMemberClick = () => {
    if (!isAdmin) {
      if (onRequestAdminUnlock) onRequestAdminUnlock();
    } else {
      setShowAddModal(true);
    }
  };

  const handleEditMemberClick = (member: CabinetMember) => {
    if (!isAdmin) {
      if (onRequestAdminUnlock) onRequestAdminUnlock();
    } else {
      setEditingMember(member);
    }
  };

  const handleDeleteMemberClick = (id: string) => {
    if (!isAdmin) {
      if (onRequestAdminUnlock) onRequestAdminUnlock();
      return;
    }
    handleDeleteMember(id);
  };

  const handleAddMember = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin) {
      if (onRequestAdminUnlock) onRequestAdminUnlock();
      return;
    }
    if (!newMember.name || !newMember.role) return;

    const created: CabinetMember = {
      id: `CAB-${String(members.length + 1).padStart(3, '0')}`,
      name: newMember.name,
      role: newMember.role,
      roleUrdu: newMember.roleUrdu || newMember.role,
      photoUrl: newMember.photoUrl || PRESET_PHOTOS[0].url,
      location: newMember.location || 'Shishi London, Drosh, Lower Chitral',
      phone: newMember.phone,
      email: newMember.email,
      bio: newMember.bio || 'Executive cabinet member contributing to community welfare.',
      isDeveloperVolunteer: newMember.isDeveloperVolunteer || false
    };

    setMembers([...members, created]);
    setShowAddModal(false);
    setNewMember({
      name: '',
      role: '',
      roleUrdu: '',
      location: 'Shishi London, Drosh, Lower Chitral',
      phone: '',
      email: '',
      bio: '',
      photoUrl: PRESET_PHOTOS[0].url,
      isDeveloperVolunteer: false
    });
  };

  const handleUpdateMember = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin) {
      if (onRequestAdminUnlock) onRequestAdminUnlock();
      return;
    }
    if (!editingMember) return;

    setMembers(prev => prev.map(m => m.id === editingMember.id ? editingMember : m));
    if (selectedMember?.id === editingMember.id) {
      setSelectedMember(editingMember);
    }
    setEditingMember(null);
  };

  const handleDeleteMember = (id: string) => {
    if (confirm('Are you sure you want to remove this cabinet profile draft?')) {
      setMembers(prev => prev.filter(m => m.id !== id));
      if (selectedMember?.id === id) setSelectedMember(null);
      if (editingMember?.id === id) setEditingMember(null);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded text-xs font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
              Executive Governance & Cabinet
            </span>
            <span className="text-xs text-slate-500 font-urdu">کابینہ اراکین و انتظامیہ</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mt-1">
            Organization Cabinet Members & Leadership Draft
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1">
            Official cabinet directory of {NGO_INFO.name}. Developed and maintained by volunteer app developers.
          </p>
        </div>

        <button
          onClick={handleAddMemberClick}
          className={`px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all shadow-md flex items-center justify-center gap-2 ${
            isAdmin ? 'bg-emerald-600 hover:bg-emerald-500 text-white' : 'bg-amber-600 hover:bg-amber-500 text-white'
          }`}
        >
          {isAdmin ? <UserPlus className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
          <span>{isAdmin ? 'Add Cabinet Draft Member' : 'Unlock Developer Mode to Add Member'}</span>
        </button>
      </div>

      {/* Developer Volunteer Disclosure Note */}
      <div className="bg-slate-900 text-white p-5 rounded-2xl border border-slate-800 shadow-md flex flex-col md:flex-row items-start md:items-center gap-4 justify-between">
        <div className="flex items-start gap-3">
          <div className="p-2.5 bg-emerald-500/10 text-emerald-400 rounded-xl mt-0.5">
            <Code2 className="w-6 h-6" />
          </div>
          <div>
            <h2 className="font-bold text-sm text-emerald-400 flex items-center gap-2">
              Application Developer Statement
            </h2>
            <p className="text-xs text-slate-300 mt-1 leading-relaxed">
              I serve strictly as the <strong>Volunteer Software Developer</strong> for this digital management system and am not the founder or executive owner of Tanzeem-e-Insani Khidmat (TIK) Shishi. Organizational authority rests with President <strong>{NGO_INFO.presidentName}</strong> and the Executive Cabinet.
            </p>
          </div>
        </div>
        <div className="px-3 py-1.5 rounded-lg bg-emerald-950/80 border border-emerald-800/60 text-emerald-300 text-xs font-medium whitespace-nowrap">
          Role: Volunteer Developer
        </div>
      </div>

      {/* Controls & Search */}
      <div className="flex flex-col sm:flex-row gap-4 justify-between items-center bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search by name, role, or village..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 dark:text-white"
          />
        </div>

        <div className="flex items-center gap-2 text-xs text-slate-500">
          <span>Total Cabinet Members: <strong>{members.length}</strong></span>
        </div>
      </div>

      {/* Executive Cabinet Members Grid (5 Members with Photos & Emails) */}
      <div className="space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-800">
          <div>
            <h2 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-500" />
              <span>Executive Cabinet Leadership</span>
            </h2>
            <p className="text-xs text-slate-500">Official 5-member executive cabinet of Tanzeem-e-Insani Khidmat (TIK) Shishi</p>
          </div>
          <span className="px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 text-xs font-bold">
            5 Cabinet Members
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredMembers.filter(m => m.isCabinetMember || m.isDeveloperVolunteer).map((member) => (
            <div 
              key={member.id}
              className={`bg-white dark:bg-slate-900 rounded-2xl border ${
                member.isDeveloperVolunteer 
                  ? 'border-emerald-500/60 shadow-emerald-500/10 shadow-lg' 
                  : 'border-slate-200 dark:border-slate-800'
              } shadow-sm overflow-hidden hover:shadow-md transition-all flex flex-col justify-between`}
            >
              <div>
                {/* Executive / Developer Member Photo Banner */}
                <div className="relative h-48 bg-slate-900 overflow-hidden">
                  <img 
                    src={member.photoUrl || PRESET_PHOTOS[0].url} 
                    alt={member.name}
                    className="w-full h-full object-cover object-center"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />
                  
                  <div className="absolute top-3 left-3">
                    <span className={`px-2.5 py-1 rounded-md text-[10px] font-extrabold uppercase tracking-wider ${
                      member.isDeveloperVolunteer
                        ? 'bg-emerald-500 text-white shadow'
                        : 'bg-emerald-500/90 text-white shadow'
                    }`}>
                      {member.role}
                    </span>
                  </div>

                  <div className="absolute bottom-3 left-3 right-3 text-white">
                    <h3 className="text-xl font-bold drop-shadow">{member.name}</h3>
                    <p className="text-xs text-emerald-300 font-urdu">{member.roleUrdu}</p>
                  </div>
                </div>

                {/* Body Details */}
                <div className="p-5 space-y-3 text-xs">
                  <p className="text-slate-600 dark:text-slate-300 leading-relaxed min-h-[2.5rem]">
                    {member.bio}
                  </p>

                  <div className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-2 text-slate-500 dark:text-slate-400">
                    <div className="flex items-center gap-2">
                      <MapPin className="w-3.5 h-3.5 text-emerald-500 flex-shrink-0" />
                      <span>Location: <strong className="text-slate-800 dark:text-slate-200">{member.location}</strong></span>
                    </div>

                    {member.email && (
                      <div className="flex items-center gap-2">
                        <Mail className="w-3.5 h-3.5 text-emerald-500 flex-shrink-0" />
                        <span>Email: <a href={`mailto:${member.email}`} className="text-emerald-600 dark:text-emerald-400 font-semibold hover:underline">{member.email}</a></span>
                      </div>
                    )}

                    {member.phone && (
                      <div className="flex items-center gap-2">
                        <Phone className="w-3.5 h-3.5 text-emerald-500 flex-shrink-0" />
                        <span>Contact No: <strong className="text-slate-800 dark:text-slate-200">{member.phone}</strong></span>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Footer */}
              <div className="px-5 py-3 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[11px] text-slate-500">
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => handleEditMemberClick(member)}
                    className="p-1.5 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 font-medium flex items-center gap-1"
                    title={isAdmin ? "Edit Profile Data" : "Unlock Developer Mode to Edit"}
                  >
                    <Edit3 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                    <span>Edit</span>
                  </button>

                  <button
                    onClick={() => handleDeleteMemberClick(member.id)}
                    className="p-1.5 rounded-lg text-red-500 hover:bg-red-50 dark:hover:bg-red-950/40"
                    title={isAdmin ? "Remove Profile" : "Unlock Developer Mode to Delete"}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                <button
                  onClick={() => setSelectedMember(member)}
                  className="text-emerald-600 hover:text-emerald-500 dark:text-emerald-400 font-bold flex items-center gap-1"
                >
                  <span>View Details</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* General Society Members Section (Without Images / Emails as requested) */}
      <div className="space-y-4 pt-6 border-t border-slate-200 dark:border-slate-800">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2">
          <div>
            <h2 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
              <Users className="w-5 h-5 text-emerald-500" />
              <span>General Society Members Directory</span>
              <span className="text-xs text-slate-400 font-urdu">عام اراکین سوسائٹی</span>
            </h2>
            <p className="text-xs text-slate-500">Complete registered society members list of Tanzeem-e-Insani Khidmat (TIK) Shishi</p>
          </div>
          <span className="px-3 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-bold self-start sm:self-auto">
            {filteredMembers.filter(m => !m.isCabinetMember && !m.isDeveloperVolunteer).length} General Members
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredMembers.filter(m => !m.isCabinetMember && !m.isDeveloperVolunteer).map((member) => (
            <div 
              key={member.id} 
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 transition-all hover:border-emerald-500/50 shadow-sm flex flex-col justify-between space-y-3"
            >
              <div>
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                      {member.role}
                    </span>
                    <h3 className="text-base font-bold text-slate-900 dark:text-white mt-1.5">{member.name}</h3>
                    <p className="text-xs text-emerald-600 dark:text-emerald-400 font-urdu">{member.roleUrdu}</p>
                  </div>
                  <div className="w-9 h-9 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 flex items-center justify-center font-black text-xs flex-shrink-0">
                    {member.name.split(' ').map(n => n[0]).slice(0, 2).join('')}
                  </div>
                </div>

                <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 mt-3">
                  <MapPin className="w-3.5 h-3.5 text-emerald-500 flex-shrink-0" />
                  <span>{member.location}</span>
                </div>
              </div>

              {member.phone && (
                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2 text-xs">
                  <div className="flex items-center gap-2 font-mono font-bold text-slate-700 dark:text-slate-300">
                    <Phone className="w-3.5 h-3.5 text-emerald-500" />
                    <span>{member.phone}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => setEditingMember(member)}
                      className="p-1 rounded text-slate-400 hover:text-emerald-500"
                      title="Edit"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                    <a
                      href={`tel:${member.phone.replace(/\s+/g, '')}`}
                      className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold transition-all shadow"
                    >
                      Call
                    </a>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Official Contact Numbers Section Below Cabinet Grid */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-850 to-emerald-950 text-white rounded-3xl p-6 sm:p-8 border border-slate-800 shadow-xl space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400">
                <Phone className="w-5 h-5" />
              </span>
              <h2 className="text-xl sm:text-2xl font-black">Official Cabinet Contact Directory</h2>
            </div>
            <p className="text-xs sm:text-sm text-slate-300 mt-1">
              Direct contact numbers for Tanzeem-e-Insani Khidmat (TIK) Shishi executive leadership.
            </p>
          </div>
          <div className="px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-bold self-start sm:self-auto">
            {members.length} Society Leadership Contacts
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {members.map((member) => (
            <div key={member.id} className="bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 rounded-2xl p-4 transition-all space-y-3 flex flex-col justify-between">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400 block mb-1">
                  {member.role}
                </span>
                <h3 className="text-base font-bold text-white">{member.name}</h3>
                <p className="text-xs text-slate-400 font-urdu">{member.roleUrdu}</p>
                <div className="flex items-center gap-1.5 text-xs text-slate-400 mt-2">
                  <MapPin className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                  <span>{member.location}</span>
                </div>
              </div>

              {member.phone && (
                <div className="pt-3 border-t border-slate-700/60 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 font-mono text-xs font-bold text-emerald-300">
                    <Phone className="w-3.5 h-3.5 text-emerald-400" />
                    <span>{member.phone}</span>
                  </div>
                  <a
                    href={`tel:${member.phone.replace(/\s+/g, '')}`}
                    className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow flex items-center gap-1"
                  >
                    <span>Call</span>
                  </a>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Profile Detail Modal */}
      {selectedMember && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full overflow-hidden border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4">
            <div className="p-6 bg-gradient-to-r from-slate-900 via-slate-800 to-emerald-950 text-white relative">
              <button
                onClick={() => setSelectedMember(null)}
                className="absolute top-4 right-4 p-1.5 rounded-full bg-slate-800/80 text-white hover:bg-slate-700"
              >
                <X className="w-4 h-4" />
              </button>
              <span className="px-2.5 py-1 rounded text-[10px] font-extrabold uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                {selectedMember.role}
              </span>
              <h2 className="text-2xl font-black mt-2">{selectedMember.name}</h2>
              <p className="text-xs text-emerald-300 font-urdu">{selectedMember.roleUrdu}</p>
            </div>

            <div className="p-6 space-y-4 text-xs">
              <div>
                <h4 className="font-bold uppercase tracking-wider text-slate-400 text-[10px]">Executive Governance & Portfolio</h4>
                <p className="text-slate-700 dark:text-slate-300 mt-1 leading-relaxed text-sm">
                  {selectedMember.bio}
                </p>
              </div>

              <div className="space-y-2 pt-3 border-t border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Jurisdiction / Location:</span>
                  <span className="font-semibold">{selectedMember.location}</span>
                </div>
                {selectedMember.email && (
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Official Email:</span>
                    <a href={`mailto:${selectedMember.email}`} className="font-semibold text-emerald-600 dark:text-emerald-400 hover:underline">{selectedMember.email}</a>
                  </div>
                )}
                {selectedMember.phone && (
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Official Contact:</span>
                    <span className="font-semibold text-emerald-600 dark:text-emerald-400 font-mono">{selectedMember.phone}</span>
                  </div>
                )}
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Role Nature:</span>
                  <span className="font-semibold text-emerald-600 dark:text-emerald-400">
                    {selectedMember.isCabinetMember ? 'Executive Cabinet Member' : selectedMember.isDeveloperVolunteer ? 'Volunteer App Developer' : 'Society Member'}
                  </span>
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  onClick={() => {
                    setEditingMember(selectedMember);
                    setSelectedMember(null);
                  }}
                  className="flex-1 py-2.5 rounded-xl bg-emerald-600 text-white font-bold hover:bg-emerald-500 transition-all text-xs flex items-center justify-center gap-2"
                >
                  <Edit3 className="w-4 h-4" />
                  <span>Edit Profile Data</span>
                </button>

                <button
                  onClick={() => setSelectedMember(null)}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold hover:bg-slate-200 dark:hover:bg-slate-700 text-xs"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Edit Cabinet Profile Modal */}
      {editingMember && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-lg w-full p-6 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <div>
                <h3 className="font-bold text-lg text-slate-900 dark:text-white flex items-center gap-2">
                  <Edit3 className="w-5 h-5 text-emerald-500" />
                  Edit Cabinet Member Profile
                </h3>
                <p className="text-xs text-slate-500">Update leadership photo, role titles, and contact details</p>
              </div>
              <button 
                onClick={() => setEditingMember(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleUpdateMember} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Full Name *</label>
                  <input
                    type="text"
                    required
                    value={editingMember.name}
                    onChange={(e) => setEditingMember({ ...editingMember, name: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Official Role Title *</label>
                  <input
                    type="text"
                    required
                    value={editingMember.role}
                    onChange={(e) => setEditingMember({ ...editingMember, role: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Role Title (Urdu)</label>
                  <input
                    type="text"
                    value={editingMember.roleUrdu}
                    onChange={(e) => setEditingMember({ ...editingMember, roleUrdu: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white font-urdu"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Village / Location</label>
                  <input
                    type="text"
                    value={editingMember.location}
                    onChange={(e) => setEditingMember({ ...editingMember, location: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Contact Phone</label>
                  <input
                    type="text"
                    value={editingMember.phone || ''}
                    onChange={(e) => setEditingMember({ ...editingMember, phone: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Official Email</label>
                  <input
                    type="email"
                    value={editingMember.email || ''}
                    onChange={(e) => setEditingMember({ ...editingMember, email: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="space-y-3 p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700/60">
                <div className="flex items-center justify-between">
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold text-xs">Member Photo</label>
                  <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold">Upload from computer or device</span>
                </div>

                <div className="flex items-center gap-3">
                  <div className="w-14 h-14 rounded-xl overflow-hidden border-2 border-emerald-500/50 bg-slate-200 dark:bg-slate-700 flex-shrink-0 relative group">
                    <img src={editingMember.photoUrl || PRESET_PHOTOS[0].url} alt="Profile preview" className="w-full h-full object-cover" />
                  </div>

                  <div className="flex-1 space-y-1">
                    <label className="cursor-pointer inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-colors shadow-sm">
                      <Upload className="w-3.5 h-3.5" />
                      <span>Choose File from Device</span>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            const reader = new FileReader();
                            reader.onload = (event) => {
                              if (event.target?.result) {
                                setEditingMember({ ...editingMember, photoUrl: event.target.result as string });
                              }
                            };
                            reader.readAsDataURL(file);
                          }
                        }}
                      />
                    </label>
                    <p className="text-[10px] text-slate-500">Supports JPG, PNG, WEBP from phone or desktop</p>
                  </div>
                </div>

                <div>
                  <span className="text-[11px] text-slate-500 block mb-1">Or paste photo URL:</span>
                  <input
                    type="url"
                    value={editingMember.photoUrl}
                    onChange={(e) => setEditingMember({ ...editingMember, photoUrl: e.target.value })}
                    placeholder="https://images.unsplash.com/photo-..."
                    className="w-full px-3 py-1.5 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white"
                  />
                </div>

                <div className="space-y-1 pt-1">
                  <span className="text-[11px] text-slate-500 block">Or pick a sample preset photo:</span>
                  <div className="grid grid-cols-6 gap-2">
                    {PRESET_PHOTOS.map((photo, i) => (
                      <button
                        key={i}
                        type="button"
                        onClick={() => setEditingMember({ ...editingMember, photoUrl: photo.url })}
                        className={`relative rounded-lg overflow-hidden border-2 h-10 ${
                          editingMember.photoUrl === photo.url ? 'border-emerald-500 ring-2 ring-emerald-500/30' : 'border-slate-200 dark:border-slate-700'
                        }`}
                      >
                        <img src={photo.url} alt={photo.label} className="w-full h-full object-cover" />
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Biography & Leadership Scope</label>
                <textarea
                  rows={3}
                  value={editingMember.bio}
                  onChange={(e) => setEditingMember({ ...editingMember, bio: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white resize-none"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <input
                  type="checkbox"
                  id="editIsDeveloperVolunteer"
                  checked={editingMember.isDeveloperVolunteer || false}
                  onChange={(e) => setEditingMember({ ...editingMember, isDeveloperVolunteer: e.target.checked })}
                  className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500"
                />
                <label htmlFor="editIsDeveloperVolunteer" className="text-slate-700 dark:text-slate-300 text-xs">
                  Mark as Volunteer Technical Developer / App Contributor
                </label>
              </div>

              <div className="flex justify-between items-center pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => handleDeleteMember(editingMember.id)}
                  className="px-3 py-1.5 rounded-lg text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30 text-xs font-semibold flex items-center gap-1"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Delete Profile</span>
                </button>

                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setEditingMember(null)}
                    className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold flex items-center gap-1.5"
                  >
                    <Save className="w-4 h-4" />
                    <span>Save Changes</span>
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add New Cabinet Draft Member Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-lg w-full p-6 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <div>
                <h3 className="font-bold text-lg text-slate-900 dark:text-white">Add Cabinet Member Draft</h3>
                <p className="text-xs text-slate-500">Enter executive details and draft photo link</p>
              </div>
              <button 
                onClick={() => setShowAddModal(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddMember} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Full Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Muhammad Rahim"
                    value={newMember.name}
                    onChange={(e) => setNewMember({ ...newMember, name: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Official Role Title *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Education Director"
                    value={newMember.role}
                    onChange={(e) => setNewMember({ ...newMember, role: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Role Title (Urdu)</label>
                  <input
                    type="text"
                    placeholder="e.g. ناظم تعلیم"
                    value={newMember.roleUrdu}
                    onChange={(e) => setNewMember({ ...newMember, roleUrdu: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white font-urdu"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Village / Location</label>
                  <input
                    type="text"
                    placeholder="e.g. Tar Village, Shishi"
                    value={newMember.location}
                    onChange={(e) => setNewMember({ ...newMember, location: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Contact Phone</label>
                  <input
                    type="text"
                    placeholder="+92 3XX XXXXXXX"
                    value={newMember.phone}
                    onChange={(e) => setNewMember({ ...newMember, phone: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Official Email</label>
                  <input
                    type="email"
                    placeholder="member@tikshishi.org"
                    value={newMember.email}
                    onChange={(e) => setNewMember({ ...newMember, email: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="space-y-3 p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700/60">
                <div className="flex items-center justify-between">
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold text-xs">Member Photo</label>
                  <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold">Upload from computer or device</span>
                </div>

                <div className="flex items-center gap-3">
                  <div className="w-14 h-14 rounded-xl overflow-hidden border-2 border-emerald-500/50 bg-slate-200 dark:bg-slate-700 flex-shrink-0 relative group">
                    <img src={newMember.photoUrl || PRESET_PHOTOS[0].url} alt="Profile preview" className="w-full h-full object-cover" />
                  </div>

                  <div className="flex-1 space-y-1">
                    <label className="cursor-pointer inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-colors shadow-sm">
                      <Upload className="w-3.5 h-3.5" />
                      <span>Choose File from Device</span>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            const reader = new FileReader();
                            reader.onload = (event) => {
                              if (event.target?.result) {
                                setNewMember({ ...newMember, photoUrl: event.target.result as string });
                              }
                            };
                            reader.readAsDataURL(file);
                          }
                        }}
                      />
                    </label>
                    <p className="text-[10px] text-slate-500">Upload direct photo from gallery or computer</p>
                  </div>
                </div>

                <div>
                  <span className="text-[11px] text-slate-500 block mb-1">Or paste photo URL:</span>
                  <input
                    type="url"
                    placeholder="https://images.unsplash.com/photo-..."
                    value={newMember.photoUrl}
                    onChange={(e) => setNewMember({ ...newMember, photoUrl: e.target.value })}
                    className="w-full px-3 py-1.5 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white"
                  />
                </div>

                <div className="space-y-1 pt-1">
                  <span className="text-[11px] text-slate-500 block">Or pick a sample preset photo:</span>
                  <div className="grid grid-cols-6 gap-2">
                    {PRESET_PHOTOS.map((photo, i) => (
                      <button
                        key={i}
                        type="button"
                        onClick={() => setNewMember({ ...newMember, photoUrl: photo.url })}
                        className={`relative rounded-lg overflow-hidden border-2 h-10 ${
                          newMember.photoUrl === photo.url ? 'border-emerald-500 ring-2 ring-emerald-500/30' : 'border-slate-200 dark:border-slate-700'
                        }`}
                      >
                        <img src={photo.url} alt={photo.label} className="w-full h-full object-cover" />
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Biography & Focus Area</label>
                <textarea
                  rows={3}
                  placeholder="Describe member responsibilities and community leadership focus..."
                  value={newMember.bio}
                  onChange={(e) => setNewMember({ ...newMember, bio: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white resize-none"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <input
                  type="checkbox"
                  id="isDeveloperVolunteer"
                  checked={newMember.isDeveloperVolunteer}
                  onChange={(e) => setNewMember({ ...newMember, isDeveloperVolunteer: e.target.checked })}
                  className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500"
                />
                <label htmlFor="isDeveloperVolunteer" className="text-slate-700 dark:text-slate-300 text-xs">
                  Mark as Volunteer Technical Developer / App Contributor
                </label>
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold"
                >
                  Save Cabinet Member Draft
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
