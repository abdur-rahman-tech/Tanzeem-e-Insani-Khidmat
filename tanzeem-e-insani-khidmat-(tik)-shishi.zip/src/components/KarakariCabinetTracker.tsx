import React, { useState } from 'react';
import { 
  Boxes, 
  UtensilsCrossed, 
  RotateCcw, 
  Plus, 
  Search, 
  Calendar, 
  MapPin, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  UserCheck, 
  Phone, 
  X, 
  Building2, 
  Sparkles,
  Archive
} from 'lucide-react';
import { Language, KarakariItem, KarakariBorrowRecord, KarakariCategory } from '../types';
import { INITIAL_KARAKARI_ITEMS, INITIAL_KARAKARI_BORROWS } from '../data/initialData';

interface KarakariCabinetTrackerProps {
  language: Language;
  isAdmin?: boolean;
  onRequestAdminUnlock?: () => void;
}

export const KarakariCabinetTracker: React.FC<KarakariCabinetTrackerProps> = ({ 
  language,
  isAdmin = false,
  onRequestAdminUnlock
}) => {
  const [items, setItems] = useState<KarakariItem[]>(INITIAL_KARAKARI_ITEMS);
  const [borrowRecords, setBorrowRecords] = useState<KarakariBorrowRecord[]>(INITIAL_KARAKARI_BORROWS);

  const [activeSubTab, setActiveSubTab] = useState<'inventory' | 'borrow_ledger'>('inventory');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  // Modals state
  const [isAddItemModalOpen, setIsAddItemModalOpen] = useState(false);
  const [isIssueModalOpen, setIsIssueModalOpen] = useState(false);
  const [itemToIssue, setItemToIssue] = useState<KarakariItem | null>(null);

  // New Item Form
  const [itemName, setItemName] = useState('');
  const [itemNameUrdu, setItemNameUrdu] = useState('');
  const [category, setCategory] = useState<KarakariCategory>('Big Cooking Utensils');
  const [totalQuantity, setTotalQuantity] = useState(5);
  const [cabinetLocation, setCabinetLocation] = useState('TIK Central Depot Cabinet A-1');
  const [condition, setCondition] = useState<KarakariItem['condition']>('Excellent');
  const [description, setDescription] = useState('');

  // Issue Form
  const [borrowerName, setBorrowerName] = useState('');
  const [borrowerCnicOrPhone, setBorrowerCnicOrPhone] = useState('');
  const [village, setVillage] = useState('Tar Village');
  const [eventPurpose, setEventPurpose] = useState<KarakariBorrowRecord['eventPurpose']>('Wedding Feast');
  const [quantityToBorrow, setQuantityToBorrow] = useState(1);
  const [expectedReturnDate, setExpectedReturnDate] = useState('');
  const [issuedByVolunteer, setIssuedByVolunteer] = useState('Abdur Rahman');
  const [issueNotes, setIssueNotes] = useState('');

  // Summary Metrics
  const totalStock = items.reduce((sum, i) => sum + i.totalQuantity, 0);
  const availableInCabinet = items.reduce((sum, i) => sum + i.availableQuantity, 0);
  const currentlyBorrowed = items.reduce((sum, i) => sum + i.borrowedQuantity, 0);
  const activeLoansCount = borrowRecords.filter(r => r.status === 'Issued').length;

  // Handle Return Item to Cabinet
  const handleReturnToCabinet = (recordId: string, itemId: string, quantity: number) => {
    const today = new Date().toISOString().split('T')[0];

    // Update Borrow Record
    setBorrowRecords(borrowRecords.map(r => {
      if (r.id === recordId) {
        return {
          ...r,
          status: 'Returned',
          actualReturnDate: today
        };
      }
      return r;
    }));

    // Return Quantity to Cabinet Inventory
    setItems(items.map(item => {
      if (item.id === itemId) {
        return {
          ...item,
          availableQuantity: item.availableQuantity + quantity,
          borrowedQuantity: Math.max(0, item.borrowedQuantity - quantity)
        };
      }
      return item;
    }));
  };

  // Handle Adding New Karakari Item
  const handleAddItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!itemName.trim()) return;

    const newItem: KarakariItem = {
      id: `KAR-${Math.floor(100 + Math.random() * 900)}`,
      itemName,
      itemNameUrdu: itemNameUrdu.trim() || itemName,
      category,
      totalQuantity: Number(totalQuantity),
      availableQuantity: Number(totalQuantity),
      borrowedQuantity: 0,
      cabinetLocation,
      condition,
      description
    };

    setItems([...items, newItem]);
    setIsAddItemModalOpen(false);
    setItemName('');
    setItemNameUrdu('');
    setDescription('');
  };

  // Handle Issuing Karakari Equipment to Community Member
  const handleIssueItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!itemToIssue || !borrowerName.trim()) return;
    if (quantityToBorrow > itemToIssue.availableQuantity) {
      alert("Requested quantity exceeds available quantity in cabinet.");
      return;
    }

    const today = new Date().toISOString().split('T')[0];
    const newRecord: KarakariBorrowRecord = {
      id: `BRW-2025-${Math.floor(100 + Math.random() * 900)}`,
      itemId: itemToIssue.id,
      itemName: itemToIssue.itemName,
      quantityBorrowed: Number(quantityToBorrow),
      borrowerName,
      borrowerCnicOrPhone,
      village,
      eventPurpose,
      issueDate: today,
      expectedReturnDate: expectedReturnDate || today,
      status: 'Issued',
      issuedByVolunteer,
      notes: issueNotes.trim() || undefined
    };

    setBorrowRecords([newRecord, ...borrowRecords]);

    // Deduct available quantity from Cabinet
    setItems(items.map(i => {
      if (i.id === itemToIssue.id) {
        return {
          ...i,
          availableQuantity: i.availableQuantity - Number(quantityToBorrow),
          borrowedQuantity: i.borrowedQuantity + Number(quantityToBorrow)
        };
      }
      return i;
    }));

    setIsIssueModalOpen(false);
    setItemToIssue(null);
    setBorrowerName('');
    setBorrowerCnicOrPhone('');
    setIssueNotes('');
  };

  const filteredItems = items.filter(item => {
    const matchesSearch = item.itemName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          item.itemNameUrdu.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          item.cabinetLocation.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCat = selectedCategory === 'all' || item.category === selectedCategory;
    return matchesSearch && matchesCat;
  });

  const filteredRecords = borrowRecords.filter(rec => {
    return rec.borrowerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
           rec.itemName.toLowerCase().includes(searchQuery.toLowerCase()) ||
           rec.village.toLowerCase().includes(searchQuery.toLowerCase());
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8">
      {/* Header Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded text-xs font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
              {language === 'ur' ? 'کاراکاری امانت ذخیرہ' : 'Community Karakari Utility Depot'}
            </span>
            {language !== 'ur' && <span className="text-xs text-slate-500 font-urdu">کاراکاری — عوامی سامانِ دیگ، خیمہ و برتن ذخیرہ</span>}
          </div>
          <h1 className={`text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mt-1 ${language === 'ur' ? 'font-urdu' : ''}`}>
            {language === 'ur' ? 'کمیونٹی کاراکاری و اجتماعی سامانِ امانت بینک' : language === 'both' ? 'Community Karakari Utility & Event Resource Bank (کمیونٹی کاراکاری امانت بینک)' : 'Community Karakari Utility & Event Resource Bank'}
          </h1>
          <p className={`text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1 ${language === 'ur' ? 'font-urdu' : ''}`}>
            {language === 'ur' 
              ? 'شادی بیاہ، غمی و نیاز اور کمیونٹی تقاریب کے لیے بڑی دیگوں، تھالیوں، خیموں (چمیانے) اور پانی کے ڈرموں کی بلا معاوضہ امانتاً فراہمی۔' 
              : 'Free public borrowing of large cooking cauldrons (pateeli/deg), serving platters, event tents, and water drums for weddings, funerals, and community feasts.'}
          </p>
        </div>

        <button
          onClick={() => setIsAddItemModalOpen(true)}
          className="px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold bg-emerald-600 hover:bg-emerald-500 text-white transition-all shadow-lg flex items-center justify-center gap-2"
        >
          <Plus className="w-4 h-4" />
          <span className={language === 'ur' ? 'font-urdu' : ''}>
            {language === 'ur' ? 'ذخیرہ میں نیا سامان شامل کریں' : 'Add Karakari Item to Resource Bank'}
          </span>
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-2">
          <div className="flex items-center justify-between">
            <span className={`text-xs text-slate-500 ${language === 'ur' ? 'font-urdu' : ''}`}>
              {language === 'ur' ? 'کل سامان انوینٹری' : 'Total Reserve Inventory'}
            </span>
            <div className="p-2 bg-emerald-50 dark:bg-emerald-950/60 rounded-lg text-emerald-600 dark:text-emerald-400">
              <Boxes className="w-5 h-5" />
            </div>
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white">
            {totalStock} {language === 'ur' ? 'عدد' : 'Units'}
          </div>
          <p className={`text-[11px] text-slate-500 ${language === 'ur' ? 'font-urdu' : ''}`}>
            {language === 'ur' ? 'ٹی آئی کے مرکزی ذخیرہ میں محفوظ' : 'Stored in TIK Central Resource Depot'}
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-2">
          <div className="flex items-center justify-between">
            <span className={`text-xs text-slate-500 ${language === 'ur' ? 'font-urdu' : ''}`}>
              {language === 'ur' ? 'دستیاب سامان' : 'Available for Borrowing'}
            </span>
            <div className="p-2 bg-blue-50 dark:bg-blue-950/60 rounded-lg text-blue-600 dark:text-blue-400">
              <CheckCircle2 className="w-5 h-5" />
            </div>
          </div>
          <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400">
            {availableInCabinet} {language === 'ur' ? 'عدد' : 'Units'}
          </div>
          <p className={`text-[11px] text-slate-500 ${language === 'ur' ? 'font-urdu' : ''}`}>
            {language === 'ur' ? 'عوام کے لیے فوری دستیاب' : 'Ready for instant public dispatch'}
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-2">
          <div className="flex items-center justify-between">
            <span className={`text-xs text-slate-500 ${language === 'ur' ? 'font-urdu' : ''}`}>
              {language === 'ur' ? 'عوام کے پاس جاری شدہ' : 'Currently Out with Public'}
            </span>
            <div className="p-2 bg-amber-50 dark:bg-amber-950/60 rounded-lg text-amber-600 dark:text-amber-400">
              <Clock className="w-5 h-5" />
            </div>
          </div>
          <div className="text-2xl font-black text-amber-600 dark:text-amber-400">
            {currentlyBorrowed} {language === 'ur' ? 'عدد' : 'Units'}
          </div>
          <p className={`text-[11px] text-slate-500 ${language === 'ur' ? 'font-urdu' : ''}`}>
            {language === 'ur' ? 'مقامی تقاریب کے لیے جاری' : 'Issued for local events'}
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-2">
          <div className="flex items-center justify-between">
            <span className={`text-xs text-slate-500 ${language === 'ur' ? 'font-urdu' : ''}`}>
              {language === 'ur' ? 'فعال ادھار کنندگان' : 'Active Borrowers'}
            </span>
            <div className="p-2 bg-purple-50 dark:bg-purple-950/60 rounded-lg text-purple-600 dark:text-purple-400">
              <UserCheck className="w-5 h-5" />
            </div>
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white">
            {activeLoansCount} {language === 'ur' ? 'خاندان' : 'Families'}
          </div>
          <p className={`text-[11px] text-slate-500 ${language === 'ur' ? 'font-urdu' : ''}`}>
            {language === 'ur' ? 'صفر روپے کرایہ / بلا معاوضہ' : '0 PKR rental charge'}
          </p>
        </div>
      </div>

      {/* Navigation Tabs Bar */}
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4 bg-white dark:bg-slate-900 p-3 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <button
            onClick={() => setActiveSubTab('inventory')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              activeSubTab === 'inventory'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
            }`}
          >
            <Archive className="w-4 h-4" />
            <span className={language === 'ur' ? 'font-urdu' : ''}>
              {language === 'ur' ? `کاراکاری انوینٹری (${items.length})` : `Karakari Reserve Inventory (${items.length})`}
            </span>
          </button>

          <button
            onClick={() => setActiveSubTab('borrow_ledger')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              activeSubTab === 'borrow_ledger'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
            }`}
          >
            <RotateCcw className="w-4 h-4" />
            <span className={language === 'ur' ? 'font-urdu' : ''}>
              {language === 'ur' ? `ادھار و واپسی کا لیجر (${borrowRecords.length})` : `Borrow & Return Ledger (${borrowRecords.length})`}
            </span>
          </button>
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            placeholder={
              language === 'ur' 
                ? (activeSubTab === 'inventory' ? "دیگیں، خیمے یا سامان تلاش کریں..." : "ادھار کنندہ یا گاؤں تلاش کریں...")
                : (activeSubTab === 'inventory' ? "Search cauldrons, tents, equipment..." : "Search borrower, village...")
            }
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className={`w-full pl-9 pr-4 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white ${language === 'ur' ? 'font-urdu' : ''}`}
          />
        </div>
      </div>

      {/* View 1: Inventory Reserve Grid */}
      {activeSubTab === 'inventory' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((item) => (
            <div 
              key={item.id}
              className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4 hover:border-emerald-500/40 transition-all flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex justify-between items-start gap-2">
                  <div>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                      {item.category}
                    </span>
                    <h3 className={`font-bold text-base text-slate-900 dark:text-white mt-1 ${language === 'ur' ? 'font-urdu' : ''}`}>
                      {language === 'ur' ? item.itemNameUrdu : item.itemName}
                    </h3>
                    {language !== 'ur' && (
                      <p className="text-xs font-urdu text-emerald-600 dark:text-emerald-400 font-semibold mt-0.5">
                        {item.itemNameUrdu}
                      </p>
                    )}
                  </div>

                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    item.condition === 'Excellent' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' : 'bg-amber-100 text-amber-800'
                  }`}>
                    {language === 'ur' 
                      ? (item.condition === 'Excellent' ? 'بہترین' : item.condition === 'Good' ? 'عمدہ' : 'مرمت درکار')
                      : item.condition
                    }
                  </span>
                </div>

                <p className={`text-xs text-slate-600 dark:text-slate-400 leading-relaxed ${language === 'ur' ? 'font-urdu' : ''}`}>
                  {item.description}
                </p>

                <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2 text-xs">
                  <div className="flex justify-between items-center">
                    <span className={`text-slate-500 ${language === 'ur' ? 'font-urdu' : ''}`}>
                      {language === 'ur' ? 'ذخیرہ کا مقام:' : 'Storage Location:'}
                    </span>
                    <strong className="text-slate-800 dark:text-slate-200 font-mono text-[11px]">{item.cabinetLocation}</strong>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-center pt-2 border-t border-slate-200 dark:border-slate-800">
                    <div className="p-1.5 bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800">
                      <span className={`text-[10px] text-slate-400 block uppercase ${language === 'ur' ? 'font-urdu' : ''}`}>
                        {language === 'ur' ? 'کل تعداد' : 'Total'}
                      </span>
                      <span className="font-bold text-slate-900 dark:text-white">{item.totalQuantity}</span>
                    </div>

                    <div className="p-1.5 bg-emerald-50 dark:bg-emerald-950/60 rounded-lg border border-emerald-200 dark:border-emerald-800">
                      <span className={`text-[10px] text-emerald-600 block uppercase ${language === 'ur' ? 'font-urdu' : ''}`}>
                        {language === 'ur' ? 'دستیاب' : 'Available'}
                      </span>
                      <span className="font-bold text-emerald-600 dark:text-emerald-400">{item.availableQuantity}</span>
                    </div>

                    <div className="p-1.5 bg-amber-50 dark:bg-amber-950/60 rounded-lg border border-amber-200 dark:border-amber-800">
                      <span className={`text-[10px] text-amber-600 block uppercase ${language === 'ur' ? 'font-urdu' : ''}`}>
                        {language === 'ur' ? 'جاری شدہ' : 'Borrowed'}
                      </span>
                      <span className="font-bold text-amber-600 dark:text-amber-400">{item.borrowedQuantity}</span>
                    </div>
                  </div>
                </div>
              </div>

              <button
                disabled={item.availableQuantity <= 0}
                onClick={() => {
                  setItemToIssue(item);
                  setQuantityToBorrow(1);
                  setIsIssueModalOpen(true);
                }}
                className={`w-full mt-4 py-2.5 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-2 ${
                  item.availableQuantity > 0
                    ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-md'
                    : 'bg-slate-200 dark:bg-slate-800 text-slate-400 cursor-not-allowed'
                }`}
              >
                <UtensilsCrossed className="w-4 h-4" />
                <span className={language === 'ur' ? 'font-urdu' : ''}>
                  {item.availableQuantity > 0 
                    ? (language === 'ur' ? 'دیہاتی کو جاری کریں' : 'Issue to Villager (Short-Term)')
                    : (language === 'ur' ? 'تمام سامان جاری ہو چکا ہے' : 'All Units Currently Borrowed')
                  }
                </span>
              </button>
            </div>
          ))}
        </div>
      )}

      {/* View 2: Borrow & Return Ledger */}
      {activeSubTab === 'borrow_ledger' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
          <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center">
            <h3 className={`font-bold text-sm text-slate-900 dark:text-white ${language === 'ur' ? 'font-urdu' : ''}`}>
              {language === 'ur' ? 'عوامی ادھار و کابینہ میں واپسی کا رجسٹر' : 'Public Borrow & Cabinet Return Records'}
            </h3>
            <span className="text-xs text-slate-500">
              Showing {filteredRecords.length} {language === 'ur' ? 'اندراج' : 'loans'}
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-700 dark:text-slate-300">
              <thead className="bg-slate-50 dark:bg-slate-950 text-slate-500 font-bold uppercase tracking-wider text-[10px] border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="p-3.5">{language === 'ur' ? 'ادھار کنندہ و رابطہ' : 'Borrower & Contact'}</th>
                  <th className="p-3.5">{language === 'ur' ? 'کاراکاری سامان' : 'Karakari Equipment'}</th>
                  <th className="p-3.5">{language === 'ur' ? 'تعداد' : 'Qty'}</th>
                  <th className="p-3.5">{language === 'ur' ? 'گاؤں و مقصد' : 'Village & Purpose'}</th>
                  <th className="p-3.5">{language === 'ur' ? 'تاریخ اجرا' : 'Issue Date'}</th>
                  <th className="p-3.5">{language === 'ur' ? 'متوقع واپسی' : 'Expected Return'}</th>
                  <th className="p-3.5">{language === 'ur' ? 'حالت' : 'Status'}</th>
                  <th className="p-3.5 text-right">{language === 'ur' ? 'کابینہ میں واپسی' : 'Cabinet Return Action'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800 font-medium">
                {filteredRecords.map((rec) => (
                  <tr key={rec.id} className="hover:bg-slate-50 dark:hover:bg-slate-950/50 transition-colors">
                    <td className="p-3.5">
                      <div className="font-bold text-slate-900 dark:text-white">{rec.borrowerName}</div>
                      <div className="text-[11px] text-slate-500">{rec.borrowerCnicOrPhone}</div>
                    </td>
                    <td className="p-3.5 font-bold text-slate-900 dark:text-white">
                      {rec.itemName}
                    </td>
                    <td className="p-3.5 font-bold text-emerald-600 dark:text-emerald-400">
                      {rec.quantityBorrowed}
                    </td>
                    <td className="p-3.5">
                      <div className="font-semibold">{rec.village}</div>
                      <div className="text-[11px] text-slate-500">{rec.eventPurpose}</div>
                    </td>
                    <td className="p-3.5 text-slate-500">{rec.issueDate}</td>
                    <td className="p-3.5 text-slate-500">{rec.expectedReturnDate}</td>
                    <td className="p-3.5">
                      {rec.status === 'Issued' ? (
                        <span className="px-2.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">
                          {language === 'ur' ? 'فعال ادھار' : 'Active Loan'}
                        </span>
                      ) : (
                        <span className="px-2.5 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                          {language === 'ur' ? 'کابینہ کو واپس' : 'Returned to Cabinet'}
                        </span>
                      )}
                    </td>
                    <td className="p-3.5 text-right">
                      {rec.status === 'Issued' ? (
                        <button
                          onClick={() => handleReturnToCabinet(rec.id, rec.itemId, rec.quantityBorrowed)}
                          className="px-3 py-1.5 rounded-lg text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white shadow-sm flex items-center justify-end gap-1 ml-auto"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />
                          <span className={language === 'ur' ? 'font-urdu' : ''}>
                            {language === 'ur' ? 'واپسی کا اندراج کریں' : 'Mark Returned to Cabinet'}
                          </span>
                        </button>
                      ) : (
                        <span className="text-[11px] text-slate-400 italic">
                          Returned on {rec.actualReturnDate}
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Modal: Add New Karakari Item to Cabinet */}
      {isAddItemModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-lg w-full p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-6 relative">
            <button
              onClick={() => setIsAddItemModalOpen(false)}
              className="absolute right-4 top-4 p-2 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="space-y-1">
              <span className="px-2.5 py-0.5 rounded text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
                {language === 'ur' ? 'نیا کاراکاری سامان' : 'New Karakari Equipment'}
              </span>
              <h2 className={`text-xl font-bold text-slate-900 dark:text-white ${language === 'ur' ? 'font-urdu' : ''}`}>
                {language === 'ur' ? 'کابینہ ڈپو میں کاراکاری سامان رجسٹر کریں' : 'Register Karakari Item to Cabinet Depot'}
              </h2>
            </div>

            <form onSubmit={handleAddItem} className="space-y-4">
              <div className="space-y-1">
                <label className={`text-xs font-bold text-slate-700 dark:text-slate-300 ${language === 'ur' ? 'font-urdu' : ''}`}>
                  {language === 'ur' ? 'سامان کا نام (انگریزی) *' : 'Item Name (English) *'}
                </label>
                <input
                  type="text"
                  required
                  value={itemName}
                  onChange={(e) => setItemName(e.target.value)}
                  placeholder="e.g. Big Cooking Cauldron (Deg / Pateeli 100 Person)"
                  className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                />
              </div>

              <div className="space-y-1">
                <label className={`text-xs font-bold text-slate-700 dark:text-slate-300 ${language === 'ur' ? 'font-urdu' : ''}`}>
                  {language === 'ur' ? 'سامان کا نام (اردو) *' : 'Item Name in Urdu (نام بمع اردو) *'}
                </label>
                <input
                  type="text"
                  required
                  value={itemNameUrdu}
                  onChange={(e) => setItemNameUrdu(e.target.value)}
                  placeholder="مثلاً: بڑا پتیلا / دیگ 100 افراد"
                  className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs font-urdu"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className={`text-xs font-bold text-slate-700 dark:text-slate-300 ${language === 'ur' ? 'font-urdu' : ''}`}>
                    {language === 'ur' ? 'سامان کا زمرہ (کیٹیگری) *' : 'Category *'}
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as any)}
                    className={`w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs font-semibold ${language === 'ur' ? 'font-urdu' : ''}`}
                  >
                    <option value="Big Cooking Utensils">{language === 'ur' ? 'بڑے پتیلے / دیگیں (Cooking Cauldrons)' : 'Big Cooking Utensils (Pateeli/Deg)'}</option>
                    <option value="Serving Platters & Dishes">{language === 'ur' ? 'تھالیاں و برتن (Serving Dishes)' : 'Serving Platters & Dishes (Thali)'}</option>
                    <option value="Event Tents & Carpets">{language === 'ur' ? 'چمیانے، خیمے و قالین (Event Tents)' : 'Event Tents & Carpets (Chamyana)'}</option>
                    <option value="Gas & Water Storage">{language === 'ur' ? 'پانی کے ڈرم و گیس سلنڈر (Gas & Water)' : 'Gas & Water Storage Drums'}</option>
                    <option value="Lighting & Sound">{language === 'ur' ? 'لائٹنگ و ساؤنڈ سپیکر (Lighting & Sound)' : 'Lighting & Sound Speakers'}</option>
                    <option value="Community Tools">{language === 'ur' ? 'کمیونٹی اوزار (Community Tools)' : 'Community Tools'}</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className={`text-xs font-bold text-slate-700 dark:text-slate-300 ${language === 'ur' ? 'font-urdu' : ''}`}>
                    {language === 'ur' ? 'کل تعداد *' : 'Total Quantity *'}
                  </label>
                  <input
                    type="number"
                    min={1}
                    required
                    value={totalQuantity}
                    onChange={(e) => setTotalQuantity(Number(e.target.value))}
                    className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs font-bold"
                  />
                </div>

                <div className="space-y-1">
                  <label className={`text-xs font-bold text-slate-700 dark:text-slate-300 ${language === 'ur' ? 'font-urdu' : ''}`}>
                    {language === 'ur' ? 'کابینہ / ذخیرہ کا مقام *' : 'Cabinet / Depot Location *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={cabinetLocation}
                    onChange={(e) => setCabinetLocation(e.target.value)}
                    placeholder="e.g. TIK Central Depot A-1"
                    className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                  />
                </div>

                <div className="space-y-1">
                  <label className={`text-xs font-bold text-slate-700 dark:text-slate-300 ${language === 'ur' ? 'font-urdu' : ''}`}>
                    {language === 'ur' ? 'سامان کی حالت *' : 'Condition *'}
                  </label>
                  <select
                    value={condition}
                    onChange={(e) => setCondition(e.target.value as any)}
                    className={`w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs ${language === 'ur' ? 'font-urdu' : ''}`}
                  >
                    <option value="Excellent">{language === 'ur' ? 'بہترین (Excellent)' : 'Excellent'}</option>
                    <option value="Good">{language === 'ur' ? 'عمدہ (Good)' : 'Good'}</option>
                    <option value="Needs Maintenance">{language === 'ur' ? 'مرمت درکار (Needs Maintenance)' : 'Needs Maintenance'}</option>
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label className={`text-xs font-bold text-slate-700 dark:text-slate-300 ${language === 'ur' ? 'font-urdu' : ''}`}>
                  {language === 'ur' ? 'تفصیل / خصوصیات' : 'Description / Specifications'}
                </label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder={language === 'ur' ? "سامان کی تفصیلا، گنجائش یا استعمال کی ہدایات..." : "Item details, size capacity, or special usage notes..."}
                  className={`w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs ${language === 'ur' ? 'font-urdu' : ''}`}
                />
              </div>

              <div className="pt-2 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsAddItemModalOpen(false)}
                  className={`px-4 py-2 rounded-lg text-xs font-semibold bg-slate-100 dark:bg-slate-800 ${language === 'ur' ? 'font-urdu' : ''}`}
                >
                  {language === 'ur' ? 'منسوخ کریں' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className={`px-6 py-2 rounded-lg text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white shadow-md ${language === 'ur' ? 'font-urdu' : ''}`}
                >
                  {language === 'ur' ? 'کابینہ میں شامل کریں' : 'Add to Cabinet Depot'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Issue Item to Villager */}
      {isIssueModalOpen && itemToIssue && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-lg w-full p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-6 relative">
            <button
              onClick={() => setIsIssueModalOpen(false)}
              className="absolute right-4 top-4 p-2 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="space-y-1">
              <span className="px-2.5 py-0.5 rounded text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
                {language === 'ur' ? 'کاراکاری سامان کا اجرا' : 'Issue Karakari Item'}
              </span>
              <h2 className={`text-xl font-bold text-slate-900 dark:text-white ${language === 'ur' ? 'font-urdu' : ''}`}>
                {language === 'ur' ? itemToIssue.itemNameUrdu : itemToIssue.itemName}
              </h2>
              <p className={`text-xs text-slate-500 ${language === 'ur' ? 'font-urdu' : ''}`}>
                {language === 'ur' ? 'کابینہ میں دستیاب تعداد:' : 'Available in Cabinet:'} <strong className="text-emerald-600">{itemToIssue.availableQuantity} {language === 'ur' ? 'عدد' : 'Units'}</strong>
              </p>
            </div>

            <form onSubmit={handleIssueItem} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className={`text-xs font-bold text-slate-700 dark:text-slate-300 ${language === 'ur' ? 'font-urdu' : ''}`}>
                    {language === 'ur' ? 'ادھار کنندہ کا مکمل نام *' : 'Borrower Full Name *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={borrowerName}
                    onChange={(e) => setBorrowerName(e.target.value)}
                    placeholder="e.g. Sher Afzal Khan"
                    className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                  />
                </div>

                <div className="space-y-1">
                  <label className={`text-xs font-bold text-slate-700 dark:text-slate-300 ${language === 'ur' ? 'font-urdu' : ''}`}>
                    {language === 'ur' ? 'شناختی کارڈ / موبائل نمبر *' : 'CNIC / Mobile Phone *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={borrowerCnicOrPhone}
                    onChange={(e) => setBorrowerCnicOrPhone(e.target.value)}
                    placeholder="+92 345 XXXXXXX"
                    className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                  />
                </div>

                <div className="space-y-1">
                  <label className={`text-xs font-bold text-slate-700 dark:text-slate-300 ${language === 'ur' ? 'font-urdu' : ''}`}>
                    {language === 'ur' ? 'گاؤں / محلہ *' : 'Village / Hamlet *'}
                  </label>
                  <select
                    value={village}
                    onChange={(e) => setVillage(e.target.value)}
                    className={`w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs ${language === 'ur' ? 'font-urdu' : ''}`}
                  >
                    <option value="Tar Village">Tar Village (گاؤں تار)</option>
                    <option value="Purigal">Purigal (پوریگل)</option>
                    <option value="Madaklasht">Madaklasht (مدک لشٹ)</option>
                    <option value="Kawash">Kawash (کاواش)</option>
                    <option value="Gorgog">Gorgog (گورگوگ)</option>
                    <option value="Shishi Village">Shishi Village (گاؤں شیشی)</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className={`text-xs font-bold text-slate-700 dark:text-slate-300 ${language === 'ur' ? 'font-urdu' : ''}`}>
                    {language === 'ur' ? 'تقریب یا استعمال کا مقصد *' : 'Event Purpose *'}
                  </label>
                  <select
                    value={eventPurpose}
                    onChange={(e) => setEventPurpose(e.target.value as any)}
                    className={`w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs font-semibold ${language === 'ur' ? 'font-urdu' : ''}`}
                  >
                    <option value="Wedding Feast">{language === 'ur' ? 'شادی کی ولیمہ و دعوت (Wedding Feast)' : 'Wedding Feast'}</option>
                    <option value="Funeral / Niaz">{language === 'ur' ? 'تعزیت / نیاز / جنازہ (Funeral / Niaz)' : 'Funeral / Condolence Niaz'}</option>
                    <option value="Community Gathering">{language === 'ur' ? 'کمیونٹی جرگہ و اجلاس (Community Gathering)' : 'Community Gathering / Jirga'}</option>
                    <option value="Emergency Relief Cookout">{language === 'ur' ? 'ہنگامی امدادی کھانا (Emergency Relief)' : 'Emergency Relief Cookout'}</option>
                    <option value="Other">{language === 'ur' ? 'دیگر اجتماعی مقصد (Other)' : 'Other Community Purpose'}</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className={`text-xs font-bold text-slate-700 dark:text-slate-300 ${language === 'ur' ? 'font-urdu' : ''}`}>
                    {language === 'ur' ? 'اجرا کی تعداد *' : 'Quantity to Issue *'}
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={itemToIssue.availableQuantity}
                    required
                    value={quantityToBorrow}
                    onChange={(e) => setQuantityToBorrow(Number(e.target.value))}
                    className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs font-bold"
                  />
                </div>

                <div className="space-y-1">
                  <label className={`text-xs font-bold text-slate-700 dark:text-slate-300 ${language === 'ur' ? 'font-urdu' : ''}`}>
                    {language === 'ur' ? 'متوقع واپسی کی تاریخ *' : 'Expected Cabinet Return Date *'}
                  </label>
                  <input
                    type="date"
                    required
                    value={expectedReturnDate}
                    onChange={(e) => setExpectedReturnDate(e.target.value)}
                    className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className={`text-xs font-bold text-slate-700 dark:text-slate-300 ${language === 'ur' ? 'font-urdu' : ''}`}>
                  {language === 'ur' ? 'اجرا کرنے والے رضا کار کا نام *' : 'Issuing Volunteer Name *'}
                </label>
                <input
                  type="text"
                  required
                  value={issuedByVolunteer}
                  onChange={(e) => setIssuedByVolunteer(e.target.value)}
                  placeholder="e.g. Abdur Rahman"
                  className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs"
                />
              </div>

              <div className="pt-2 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsIssueModalOpen(false)}
                  className={`px-4 py-2 rounded-lg text-xs font-semibold bg-slate-100 dark:bg-slate-800 ${language === 'ur' ? 'font-urdu' : ''}`}
                >
                  {language === 'ur' ? 'منسوخ کریں' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className={`px-6 py-2 rounded-lg text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white shadow-md ${language === 'ur' ? 'font-urdu' : ''}`}
                >
                  {language === 'ur' ? 'دیہاتی کو سامان جاری کریں' : 'Confirm Issue to Villager'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
